"""Shared data contracts. The application never executes a recommendation."""

from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone

CATEGORIES = ("Win32 apps", "Windows patching", "Conditional Access", "Autopilot & ESP", "Enterprise")


@dataclass
class Event:
    uid: str
    source: str
    category: str
    message: str
    timestamp: str | None = None
    line: int = 1
    event_id: str | None = None
    correlation_ids: list[str] = field(default_factory=list)
    codes: list[str] = field(default_factory=list)
    stage: str = "unknown"
    context: str = "unknown"


@dataclass
class Finding:
    id: str
    title: str
    category: str
    severity: str
    confidence: str
    summary: str
    root_cause: str
    evidence: list[str] = field(default_factory=list)
    checks: list[str] = field(default_factory=list)
    recommendations: list[str] = field(default_factory=list)
    references: list[str] = field(default_factory=list)


@dataclass
class AnalysisResult:
    events: list[Event] = field(default_factory=list)
    findings: list[Finding] = field(default_factory=list)
    sources: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    started_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    synthetic: bool = False

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class CollectionResult:
    files: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
