"""Best-effort local redaction. Values are never sent to a remote service.

Pseudonyms permit correlation within and between imports. They are identifiers,
not anonymisation: a person with the original value can reproduce the digest.
"""

from __future__ import annotations

import hashlib
import ipaddress
import re
from collections.abc import Mapping

_GUID = re.compile(r"(?i)\b[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\b")
_EMAIL = re.compile(r"(?i)(?<![\w.+-])[\w.!#$%&'*+/=?^`{|}~-]+@[\w.-]+\.[a-z]{2,}(?![\w.-])")
_IPV4 = re.compile(r"(?<![\w.])(?:\d{1,3}\.){3}\d{1,3}(?![\w.])")
_IPV6 = re.compile(r"(?<![\w:])(?:[0-9a-fA-F]{0,4}:){2,}[0-9a-fA-F:.]{0,39}(?:%[\w.-]+)?(?![\w:])")
_JWT = re.compile(r"\beyJ[A-Za-z0-9_-]{5,}\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\b")
_SID = re.compile(r"\bS-1-5-21(?:-\d+){3,}\b", re.I)
_USER_PATH = re.compile(r"(?i)(\b[a-z]:[\\/]Users[\\/]|[\\/]home[\\/]|[\\/]Users[\\/])([^\\/\s\"'<>]+)")
_BEARER = re.compile(r"(?i)(\bBearer\s+)[A-Za-z0-9._~+/=-]+")
_SECRET = re.compile(r"(?i)(\b(?:password|passwd|pwd|access[_ -]?token|refresh[_ -]?token|client[_ -]?secret|authorization|api[_ -]?key|secret)\s*[=:]\s*)(?:\"[^\"]*\"|'[^']*'|[^\s,;}]+)")
_IDENTIFIER = re.compile(
    r"(?i)(\b(?:correlation[ _-]?id|request[ _-]?id|session[ _-]?id|activity[ _-]?id|"
    r"device[ _-]?(?:id|name)|tenant[ _-]?id|app(?:lication)?[ _-]?id|object[ _-]?id|"
    r"user[ _-]?(?:id|name|principal[ _-]?name)|upn|account[ _-]?name|computer[ _-]?name|"
    r"hostname|serial[ _-]?number|hardware[ _-]?hash)\s*[=:]\s*)"
    r"(?:\"([^\"]*)\"|'([^']*)'|([^\s,;}]+))"
)
_SENSITIVE_KEYS = {
    "password", "passwd", "pwd", "accesstoken", "refreshtoken", "clientsecret",
    "authorization", "apikey", "secret", "token", "userprincipalname", "upn",
    "username", "userid", "userdisplayname", "devicename", "deviceid", "tenantid",
    "appid", "applicationid", "objectid", "correlationid", "requestid", "sessionid",
    "activityid", "relatedactivityid", "computername", "machinename", "hostname", "serialnumber", "hardwarehash", "thumbprint", "certificatethumbprint", "user", "displayname",
    "ipaddress", "clientipaddress", "serviceprincipalid", "alternatesigninname",
}
_SECRET_KEYS = {"password", "passwd", "pwd", "accesstoken", "refreshtoken", "clientsecret", "authorization", "apikey", "secret", "token"}


def pseudonym(value: str, kind: str = "id") -> str:
    """Use the same non-reversible display token for the same normalized identifier."""
    digest = hashlib.sha256(str(value).strip().strip("{}").casefold().encode("utf-8")).hexdigest()[:12]
    return f"[{kind}:{digest}]"


def _address(match: re.Match) -> str:
    value = match.group(0)
    try:
        ipaddress.ip_address(value.split("%", 1)[0])
    except ValueError:
        return value
    return pseudonym(value, "ip")


def redact(text: str) -> str:
    """Redact common secrets/identifiers, preserving actionable diagnostic codes."""
    value = str(text)
    value = _BEARER.sub(lambda m: m.group(1) + "[secret]", value)
    value = _SECRET.sub(lambda m: m.group(1) + "[secret]", value)
    value = _JWT.sub("[secret]", value)
    value = _SID.sub(lambda m: pseudonym(m.group(0), "sid"), value)
    value = _USER_PATH.sub(lambda m: m.group(0) if m.group(2).startswith("[user:") else m.group(1) + pseudonym(m.group(2), "user"), value)
    value = re.sub(r"(?i)(\b(?:on|for|from)\s+(?:device|computer|host)\s+)([A-Za-z0-9][\w.-]*)(?![\w.-])", lambda m: m.group(1) + pseudonym(m.group(2)), value)
    value = re.sub(r"(?i)(\b(?:certificate[ _-]?)?thumbprint\s*[=:]\s*)[0-9a-f]{20,128}\b", lambda m: m.group(1) + "[certificate]", value)

    def identifier(match: re.Match) -> str:
        original = next((v for v in match.groups()[1:] if v is not None), "")
        if original.startswith("[") or original.casefold() in {"true", "false", "null", "none", "unknown", "n/a"}:
            return match.group(0)
        return match.group(1) + pseudonym(original)

    value = _IDENTIFIER.sub(identifier, value)
    value = _GUID.sub(lambda m: pseudonym(m.group(0)), value)
    value = _EMAIL.sub(lambda m: pseudonym(m.group(0), "email"), value)
    value = _IPV4.sub(_address, value)
    value = _IPV6.sub(_address, value)
    # Domain-qualified account names commonly appear without a field label.
    value = re.sub(r"(?<![\w:/\\])([A-Za-z][\w.-]*\\)([A-Za-z][\w.$-]*)(?![\\/\w])", lambda m: pseudonym(m.group(0), "account"), value)
    return value


def redact_data(value):
    """Recursively redact exported reports and structured input metadata."""
    if isinstance(value, Mapping):
        result = {}
        for key, item in value.items():
            clean_key = re.sub(r"[\s_-]", "", str(key)).casefold()
            if clean_key in _SENSITIVE_KEYS and item is not None and not isinstance(item, (Mapping, list, tuple)):
                # Keep a pseudonym that an already-redacted Event uses unchanged.
                if isinstance(item, str) and item.startswith("[") and item.endswith("]"):
                    result[key] = item
                else:
                    result[key] = "[secret]" if clean_key in _SECRET_KEYS else pseudonym(str(item), "ip" if "ipaddress" in clean_key else "id")
            else:
                result[key] = redact_data(item)
        return result
    if isinstance(value, (list, tuple)):
        return [redact_data(item) for item in value]
    if isinstance(value, str):
        return redact(value)
    return value
