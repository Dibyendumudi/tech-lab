"""Desktop entry point and offline command-line analysis."""

import argparse
import sys
from pathlib import Path
from . import __version__
from .resources import resource_path

IMPORT_SUFFIXES = {'.log', '.txt', '.json', '.jsonl', '.ndjson', '.csv', '.xml'}


def _inputs(values: list[str]) -> list[Path]:
    paths = []
    for value in values:
        path = Path(value)
        if path.is_dir():
            paths.extend(sorted(item for item in path.iterdir() if item.is_file() and item.suffix.lower() in IMPORT_SUFFIXES and item.name != 'manifest.json'))
        else:
            paths.append(path)
    return list(dict.fromkeys(paths))


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description='Windows Diagnostics · Managed by Dibyendu. Read-only endpoint diagnostics. No fixes or settings changes.')
    parser.add_argument('--version', action='version', version=__version__)
    sub = parser.add_subparsers(dest='command')
    analysis = sub.add_parser('analyze', help='Analyze exported logs locally, without a desktop.')
    analysis.add_argument('paths', nargs='*', help='Log files or directories (one level).')
    analysis.add_argument('--sample', action='store_true', help='Analyze synthetic examples, not your device.')
    analysis.add_argument('--output', type=Path, required=True, help='New HTML/JSON report file; existing files are never overwritten.')
    analysis.add_argument('--format', choices=('html', 'json'), help='Default: inferred from the output extension.')
    collection = sub.add_parser('collect', help='Windows only: read logs and write new local diagnostic artifacts.')
    collection.add_argument('--output', type=Path, required=True, help='Parent directory for a unique collection folder.')
    collection.add_argument('--max-events', type=int, default=500)
    args = parser.parse_args(argv)
    if args.command is None:
        try:
            from .ui import launch
            launch()
            return 0
        except Exception as exc:
            # Avoid printing native OS exceptions containing raw user paths.
            from .privacy import redact
            print(f'Desktop could not start: {redact(str(exc))}', file=sys.stderr)
            print('Use a Windows desktop with Python + Tcl/Tk, or run: python -m windows_diagnostics analyze --sample --output sample-report.html', file=sys.stderr)
            return 2
    try:
        from .privacy import redact
        if args.command == 'collect':
            from .collector import collect_windows
            result = collect_windows(args.output, max_events=args.max_events)
            print(f'Collected {len(result.files)} local diagnostic files. Raw collection artifacts may contain sensitive data.')
            for warning in result.warnings:
                print(f'Notice: {redact(warning)}')
            return 0 if result.files else 2
        from .engine import analyze_files
        from .reports import write_report
        if args.sample and args.paths:
            parser.error('Use either --sample or input paths.')
        paths = _inputs([str(resource_path('examples'))] if args.sample else args.paths)
        if not paths:
            parser.error('Supply log paths or --sample.')
        result = analyze_files(paths)
        result.synthetic = args.sample
        fmt = args.format or ('json' if args.output.suffix.lower() == '.json' else 'html')
        report = write_report(result, args.output, format=fmt)
        if args.sample:
            print('SYNTHETIC SAMPLE — this report does not describe your device.')
        print(f'Analyzed {len(result.events)} events; {len(result.findings)} findings. Report: {redact(str(report))}')
        for finding in result.findings:
            print(f'  {finding.severity.upper()} / {finding.confidence}: {finding.title}')
        for warning in result.warnings:
            print(f'Notice: {redact(warning)}')
        return 0 if result.events else 2
    except (OSError, RuntimeError, ValueError) as exc:
        from .privacy import redact
        print(f'Error: {redact(str(exc))}', file=sys.stderr)
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
