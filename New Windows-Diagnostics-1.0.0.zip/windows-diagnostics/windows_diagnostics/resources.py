"""Resolve bundled project data in source checkouts and packaged desktop apps."""

import sys
from pathlib import Path


def resource_path(relative: str) -> Path:
    if hasattr(sys, "_MEIPASS"):
        return Path(sys._MEIPASS) / relative
    project_root = Path(__file__).resolve().parent.parent
    project_file = project_root / relative
    if (project_root / "desktop_entry.py").is_file() and project_file.exists():
        return project_file
    return Path(__file__).resolve().parent / "data" / relative
