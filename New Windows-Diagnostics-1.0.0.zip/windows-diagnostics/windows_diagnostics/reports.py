"""Offline redacted reports. No remote assets, telemetry or executable fixes."""

import html
import json
from pathlib import Path
from .models import AnalysisResult
from .privacy import redact_data


def _e(value) -> str:
    return html.escape(str(value if value is not None else "Unknown"), quote=True)


def _items(items: list[str]) -> str:
    return "<ol>" + "".join(f"<li>{_e(item)}</li>" for item in items) + "</ol>"


def _html(data: dict) -> str:
    events = data["events"]
    findings = data["findings"]
    by_id = {event["uid"]: (index, event) for index, event in enumerate(events)}
    cards = []
    for finding in findings:
        evidence = []
        for uid in finding["evidence"]:
            match = by_id.get(uid)
            if match:
                index, event = match
                evidence.append(f'<a href="#event-{index}">{_e(event["source"])} · line {_e(event["line"])} · {_e(event["timestamp"])}</a>')
        references = []
        for reference in finding["references"]:
            # Only link documented Microsoft references, never arbitrary imported URLs.
            if reference.startswith("https://learn.microsoft.com/"):
                references.append(f'<a href="{_e(reference)}" rel="noreferrer">Microsoft documentation</a>')
        cards.append(f'''<article class="finding">
          <div class="meta">{_e(finding['category'])} · {_e(finding['severity'])} · {_e(finding['confidence'])} confidence</div>
          <h2>{_e(finding['title'])}</h2><p>{_e(finding['summary'])}</p>
          <h3>Likely root cause</h3><p>{_e(finding['root_cause'])}</p>
          <h3>Evidence</h3><div class="evidence">{'<br>'.join(evidence) or 'No linked evidence.'}</div>
          <h3>Verify before changing anything</h3>{_items(finding['checks'])}
          <h3>Suggested resolution · not executed</h3>{_items(finding['recommendations'])}
          <div class="refs">{' · '.join(references)}</div></article>''')
    if not cards:
        cards.append('<article class="finding"><h2>No recognized failure pattern</h2><p>This is not a clean bill of health. Review source coverage and the timeline; missing data and unsupported formats can limit analysis.</p></article>')
    rows = []
    for index, event in sorted(enumerate(events), key=lambda pair: (pair[1]['timestamp'] is None, pair[1]['timestamp'] or '', pair[0])):
        rows.append(f'''<tr id="event-{index}"><td>{_e(event['timestamp'])}<small>{_e(event['category'])}</small></td>
          <td>{_e(event['source'])}<small>Line {_e(event['line'])} · event {_e(event['event_id'])}</small></td>
          <td>{_e(event['stage'])}<small>{_e(event['context'])}</small></td>
          <td><pre>{_e(event['message'])}</pre><small>{_e(', '.join(event['codes']))}</small><small>{_e(', '.join(event['correlation_ids']))}</small></td></tr>''')
    groups: dict[str, list[dict]] = {}
    for event in events:
        for identity in event['correlation_ids']:
            groups.setdefault(identity, []).append(event)
    traces = []
    for identity, group in groups.items():
        if len(group) < 2:
            continue
        ordered = sorted(group, key=lambda event: (event['timestamp'] is None, event['timestamp'] or '', event['line']))
        stages = ' → '.join(_e(event['stage']) for event in ordered if event['stage'] != 'unknown') or 'Stages unavailable'
        links = ' · '.join(f'<a href="#event-{by_id[event["uid"]][0]}">{_e(event["source"])}:{_e(event["line"])}</a>' for event in ordered)
        traces.append(f'<div class="trace"><strong>{_e(identity)}</strong><p>{stages}</p><small>{links}</small></div>')
    warnings = ''.join(f'<li>{_e(warning)}</li>' for warning in data['warnings'])
    sources = ''.join(f'<li>{_e(source)}</li>' for source in data['sources'])
    errors = sum(finding['severity'].lower() in {'critical', 'high', 'error'} for finding in findings)
    demo_note = '<div class="panel note"><strong>SYNTHETIC SAMPLE</strong><p>These demonstration records do not describe your device. Import real logs for an actual investigation.</p></div>' if data.get('synthetic') else ''
    return f'''<!doctype html><html lang="en"><head><meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1"><meta name="referrer" content="no-referrer">
    <title>Windows Diagnostics · Managed by Dibyendu</title><style>
    :root{{color-scheme:light;font-family:Segoe UI,system-ui,sans-serif;color:#20304b;background:#edf2f7}}
    *{{box-sizing:border-box}}body{{margin:0}}header{{background:#11223b;color:white;padding:42px max(24px,calc((100vw - 1180px)/2))}}
    header small{{color:#70dfd0;letter-spacing:2px;font-weight:700}}h1{{font-size:32px;margin:10px 0}}h2{{font-size:21px;margin:8px 0 16px}}h3{{font-size:14px;margin-top:24px}}
    p,li{{line-height:1.65}}a{{color:#087c79;overflow-wrap:anywhere}}main{{max-width:1180px;margin:26px auto;padding:0 24px 50px}}.stats{{display:grid;grid-template-columns:repeat(3,1fr);gap:16px}}
    .stat,.finding,.panel{{background:white;border:1px solid #dce5ee;border-radius:12px;padding:24px;margin-bottom:20px}}.stat strong{{display:block;font-size:32px;color:#0a827c}}.stat span,.meta,small{{color:#64738a;font-size:12px}}
    .meta{{text-transform:uppercase;letter-spacing:1px}}.evidence{{border-left:3px solid #16a89a;padding-left:16px;line-height:1.8}}.refs{{margin-top:20px;font-size:12px}}.note{{border-left:3px solid #d7a42e;padding:0 16px}}
    table{{width:100%;border-collapse:collapse;font-size:13px}}th,td{{text-align:left;padding:14px 10px;border-bottom:1px solid #e6edf4;vertical-align:top}}td small{{display:block;margin-top:6px;overflow-wrap:anywhere}}pre{{font:inherit;white-space:pre-wrap;overflow-wrap:anywhere;margin:0;line-height:1.5}}.table-wrap{{overflow-x:auto}}.trace{{padding:14px 0;border-bottom:1px solid #e6edf4}}
    .trace strong{{font:12px Consolas,monospace}}.trace p{{margin:6px 0}}footer{{font-size:12px;color:#64738a;line-height:1.7}}@media(max-width:700px){{.stats{{grid-template-columns:1fr}}header{{padding:28px 24px}}h1{{font-size:26px}}}}
    @media print{{body{{background:white}}header{{background:white;color:#11223b;padding:12px}}main{{padding:0}}.finding{{break-inside:avoid}}a{{text-decoration:none}}}}
    </style></head><body><header><small>WINDOWS DIAGNOSTICS / MANAGED BY DIBYENDU</small><h1>Windows diagnostics report</h1>
    <p>Read-only analysis · Local processing · Suggestions only</p></header><main>{demo_note}
    <div class="stats"><div class="stat"><strong>{len(events)}</strong><span>Events analyzed</span></div><div class="stat"><strong>{len(findings)}</strong><span>Evidence-backed findings</span></div><div class="stat"><strong>{errors}</strong><span>High-severity findings</span></div></div>
    <div class="panel"><h2>Scope &amp; limitations</h2><p>Generated {_e(data['started_at'])}. No fixes were executed and no existing settings were changed. Findings describe evidence and hypotheses from the imported records; they do not prove tenant assignments, policy configuration or device health without the relevant source data.</p>
    <p class="note">Identifiers and common sensitive values have been redacted. Redaction is heuristic; manually review before sharing. Source timestamps without a time zone remain local/unspecified. Records close in time alone do not establish causality.</p>
    <h3>Imported sources</h3><ul>{sources or '<li>No sources imported.</li>'}</ul><h3>Coverage &amp; import notices</h3><ul>{warnings or '<li>No import warnings reported.</li>'}</ul></div>
    {''.join(cards)}<section class="panel"><h2>Assignment → policy → execution → result</h2><p>These traces group records sharing an identifier. Shared identifiers show a relationship, not proof of causation. Check the timestamp, source and outcome for each step.</p>{''.join(traces) or '<p>No shared identifiers were available to construct a trace.</p>'}</section>
    <section class="panel"><h2>Evidence timeline</h2><div class="table-wrap"><table><thead><tr><th>Time</th><th>Source</th><th>Stage / context</th><th>Evidence</th></tr></thead><tbody>{''.join(rows)}</tbody></table></div></section>
    <footer>Windows Diagnostics · Managed by Dibyendu · Enterprise Intune diagnostics. Review one proposed remediation at a time in your approved change process. This application does not apply recommendations, send telemetry, or upload logs.</footer></main></body></html>'''


def write_report(result: AnalysisResult, path: str | Path, format: str = "html") -> Path:
    """Write a new redacted report. Refuse to overwrite an existing file."""
    if format not in {"html", "json"}:
        raise ValueError("Report format must be html or json.")
    target = Path(path)
    data = redact_data(result.to_dict())
    data['report_metadata'] = {
        'application': 'Windows Diagnostics', 'managed_by': 'Dibyendu', 'version': '1.0.0',
        'read_only': True, 'remediations_executed': False,
        'synthetic': result.synthetic,
        'redaction': 'Best-effort; review before sharing.',
    }
    content = _html(data) if format == "html" else json.dumps(data, indent=2, ensure_ascii=False)
    with target.open("x", encoding="utf-8", newline="\n") as handle:
        handle.write(content)
    return target
