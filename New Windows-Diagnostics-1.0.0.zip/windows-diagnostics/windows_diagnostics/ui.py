"""Local, read-only Windows endpoint analysis desktop application.

Tk widgets are only touched by the main thread. Workers return their results
through a queue; recommendations are displayed and never executed.
"""

from __future__ import annotations

from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
import platform
import queue
import threading
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from .models import AnalysisResult, CATEGORIES, Event, Finding


NAVY = "#112238"
NAVY_LIGHT = "#1b334d"
NAVY_MUTED = "#9caec3"
BACKGROUND = "#f2f5f9"
CARD = "#ffffff"
INK = "#172b43"
MUTED = "#62748a"
BORDER = "#dce5ef"
TEAL = "#087f82"
TEAL_LIGHT = "#e6f4f3"
AMBER = "#966009"
AMBER_LIGHT = "#fff5df"
RED = "#ad3841"
FONT = "Segoe UI"
MONO_FONT = "Consolas"

GUIDES = (
    {
        "title": "01  Win32 app deployment",
        "category": "Win32 apps",
        "sources": (
            r"C:\ProgramData\Microsoft\IntuneManagementExtension\Logs\AppWorkload.log",
            r"C:\ProgramData\Microsoft\IntuneManagementExtension\Logs\IntuneManagementExtension.log",
            r"C:\ProgramData\Microsoft\IntuneManagementExtension\Logs\AppActionProcessor.log",
        ),
        "checks": "Trace assignment → policy → execution → result. Verify the app's assignment, requirements, dependencies, detection rule, SYSTEM or User context, install command, and return-code mapping. A failed detection after a successful install is a different stage from an installer failure.",
    },
    {
        "title": "02  Windows patching",
        "category": "Windows patching",
        "sources": (
            "Microsoft-Windows-WindowsUpdateClient/Operational",
            r"C:\Windows\Logs\CBS\CBS.log",
            r"C:\Windows\Logs\UpdateOrchestrator",
            "Microsoft-Windows-DeviceManagement-Enterprise-Diagnostics-Provider/Admin",
        ),
        "checks": "Correlate policy delivery and update ring settings with scan, download, installation, and servicing events. Review deadlines, restart state, network or proxy errors, and the first relevant failure. CBS.log may contain errors unrelated to the incident; preserve its timestamps and context.",
    },
    {
        "title": "03  Conditional Access",
        "category": "Conditional Access",
        "sources": (
            "Microsoft Entra admin center → Monitoring & health → Sign-in logs",
            "Sign-in event → Conditional Access, Device info, and Authentication details",
            "Export the relevant sign-in events as JSON or CSV",
        ),
        "checks": "A local Windows log cannot show the complete tenant policy evaluation. Match the sign-in correlation ID and timestamp with the Entra sign-in export. Review the failed policy, MFA result, device compliance, join type, and the device record used for that sign-in.",
    },
    {
        "title": "04  Windows Autopilot & ESP",
        "category": "Autopilot & ESP",
        "sources": (
            "Microsoft-Windows-ModernDeployment-Diagnostics-Provider/Autopilot",
            "Microsoft-Windows-DeviceManagement-Enterprise-Diagnostics-Provider/Admin",
            "Microsoft-Windows-Provisioning-Diagnostics-Provider/Admin",
        ),
        "checks": "Review hardware hash registration, profile assignment, enrollment, and Enrollment Status Page app timing. Correlate TPM, DNS, proxy, and connectivity evidence with the failed enrollment stage. A timeout alone does not identify the responsible application or network dependency.",
    },
)


def _safe(value: object) -> str:
    """Redact at the presentation boundary as a second privacy safeguard."""
    text = "" if value is None else str(value)
    try:
        from .privacy import redact
        return redact(text)
    except ImportError:
        # The engine owns redaction; this fallback also allows a UI-only smoke test.
        return text


def _timestamp_key(event: Event) -> tuple[float, str, int]:
    value = event.timestamp
    if value:
        try:
            parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
            if parsed.tzinfo is None:
                parsed = parsed.replace(tzinfo=timezone.utc)
            return parsed.timestamp(), event.source, event.line
        except ValueError:
            pass
    return float("inf"), event.source, event.line


def _sample_files() -> list[str]:
    directories: list[Path] = []
    try:
        from .resources import resource_path
        directories.append(Path(resource_path("examples")))
    except (ImportError, TypeError, AttributeError):
        pass
    directories.extend((Path(__file__).resolve().parent / "examples", Path(__file__).resolve().parent.parent / "examples"))
    for directory in directories:
        if directory.is_dir():
            files = sorted(str(path) for path in directory.iterdir() if path.is_file() and path.suffix.lower() in {".log", ".txt", ".json", ".csv", ".xml"})
            if files:
                return files
    raise FileNotFoundError("The bundled synthetic examples could not be found. Import log files to begin an analysis.")


class DiagnosticApp:
    """Native desktop workspace for reviewing endpoint evidence."""

    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("Windows Diagnostics | Managed by Dibyendu")
        self.root.geometry("1420x920")
        self.root.minsize(1060, 720)
        self.root.configure(bg=BACKGROUND)
        self.result = AnalysisResult()
        self.demo = False
        self.busy = False
        self.closed = False
        self.active_page = "overview"
        self.selected_finding: Finding | None = None
        self.finding_rows: dict[str, Finding] = {}
        self.event_rows: dict[str, Event] = {}
        self.filter_after: str | None = None
        self.jobs: queue.Queue = queue.Queue()
        self.search = tk.StringVar()
        self.category = tk.StringVar(value="All domains")
        self.severity = tk.StringVar(value="All severities")
        self.status = tk.StringVar(value="Ready · Import local logs to begin")
        self._style()
        self._build()
        self._refresh()
        self.root.protocol("WM_DELETE_WINDOW", self._close)
        self.root.after(100, self._poll)
        self.search.trace_add("write", lambda *_: self._schedule_filter())
        self.category.trace_add("write", lambda *_: self._refresh_filtered())
        self.severity.trace_add("write", lambda *_: self._refresh_filtered())

    def _style(self) -> None:
        style = ttk.Style(self.root)
        style.theme_use("clam")
        self.root.option_add("*Font", (FONT, 10))
        self.root.option_add("*Listbox.font", (FONT, 10))
        style.configure("TFrame", background=BACKGROUND)
        style.configure("Card.TFrame", background=CARD)
        style.configure("TLabel", background=BACKGROUND, foreground=INK, font=(FONT, 10))
        style.configure("Muted.TLabel", background=BACKGROUND, foreground=MUTED, font=(FONT, 9))
        style.configure("Card.TLabel", background=CARD, foreground=INK, font=(FONT, 10))
        style.configure("TButton", background=CARD, foreground=INK, bordercolor=BORDER, focuscolor=TEAL, padding=(12, 9), font=(FONT, 10))
        style.map("TButton", background=[("active", "#eaf0f6"), ("disabled", "#edf1f6")], foreground=[("disabled", "#8c9aab")])
        style.configure("Accent.TButton", background=TEAL, foreground="white", bordercolor=TEAL, padding=(15, 9), font=(FONT, 10, "bold"))
        style.map("Accent.TButton", background=[("active", "#096b6d"), ("disabled", "#86b8b9")], foreground=[("disabled", "#e9f4f4")])
        style.configure("TCombobox", fieldbackground=CARD, background=CARD, bordercolor=BORDER, foreground=INK, padding=6)
        style.map("TCombobox", fieldbackground=[("readonly", CARD)], selectbackground=[("readonly", CARD)], selectforeground=[("readonly", INK)])
        style.configure("TEntry", fieldbackground=CARD, bordercolor=BORDER, padding=8)
        style.configure("Treeview", background=CARD, fieldbackground=CARD, foreground=INK, rowheight=35, borderwidth=0, font=(FONT, 10))
        style.configure("Treeview.Heading", background="#edf2f7", foreground=MUTED, relief="flat", padding=(9, 11), font=(FONT, 9, "bold"))
        style.map("Treeview", background=[("selected", "#d9eeef")], foreground=[("selected", INK)])
        style.map("Treeview.Heading", background=[("active", "#e6edf5")])
        style.configure("Horizontal.TProgressbar", background=TEAL, troughcolor=BORDER, borderwidth=0, thickness=3)
        style.configure("TPanedwindow", background=BACKGROUND)
        style.configure("Vertical.TScrollbar", background="#d6e0ea", troughcolor=CARD, borderwidth=0, arrowsize=12)

    def _build(self) -> None:
        self.shell = tk.Frame(self.root, bg=BACKGROUND)
        self.shell.pack(fill="both", expand=True)
        self.shell.grid_columnconfigure(1, weight=1)
        self.shell.grid_rowconfigure(0, weight=1)
        self._sidebar()
        self.main = tk.Frame(self.shell, bg=BACKGROUND)
        self.main.grid(row=0, column=1, sticky="nsew")
        self.main.grid_columnconfigure(0, weight=1)
        self.main.grid_rowconfigure(3, weight=1)
        self._header()
        self._filters()
        self.banner = tk.Frame(self.main, bg=AMBER_LIGHT)
        self.banner.grid(row=2, column=0, sticky="ew", padx=26, pady=(0, 12))
        self.banner_text = tk.Label(self.banner, text="", bg=AMBER_LIGHT, fg=AMBER, font=(FONT, 9), anchor="w", padx=12, pady=9)
        self.banner_text.pack(fill="x")
        self.pages_host = tk.Frame(self.main, bg=BACKGROUND)
        self.pages_host.grid(row=3, column=0, sticky="nsew", padx=26, pady=(0, 14))
        self.pages_host.grid_rowconfigure(0, weight=1)
        self.pages_host.grid_columnconfigure(0, weight=1)
        self.pages: dict[str, tk.Frame] = {}
        for name in ("overview", "findings", "timeline", "guide"):
            frame = tk.Frame(self.pages_host, bg=BACKGROUND)
            frame.grid(row=0, column=0, sticky="nsew")
            self.pages[name] = frame
        self._overview(self.pages["overview"])
        self._findings(self.pages["findings"])
        self._timeline(self.pages["timeline"])
        self._guide(self.pages["guide"])
        self._footer()
        self._navigate("overview")

    def _sidebar(self) -> None:
        sidebar = tk.Frame(self.shell, bg=NAVY, width=224)
        sidebar.grid(row=0, column=0, sticky="ns")
        sidebar.grid_propagate(False)
        tk.Label(sidebar, text="W", bg=TEAL, fg="white", font=(FONT, 23, "bold"), width=2, pady=6).pack(anchor="w", padx=23, pady=(28, 12))
        tk.Label(sidebar, text="WINDOWS", bg=NAVY, fg="white", font=(FONT, 18, "bold"), anchor="w").pack(fill="x", padx=23)
        tk.Label(sidebar, text="D I A G N O S T I C S", bg=NAVY, fg=NAVY_MUTED, font=(FONT, 8), anchor="w").pack(fill="x", padx=24, pady=(4, 10))
        tk.Label(sidebar, text="Managed by Dibyendu", bg=NAVY, fg=NAVY_MUTED, font=(FONT, 9), anchor="w").pack(fill="x", padx=24, pady=(0, 20))
        tk.Label(sidebar, text="WORKSPACE", bg=NAVY, fg=NAVY_MUTED, font=(FONT, 8, "bold"), anchor="w").pack(fill="x", padx=24, pady=(0, 9))
        self.nav_buttons: dict[str, tk.Button] = {}
        for name, title in (("overview", "Overview"), ("findings", "Findings"), ("timeline", "Evidence timeline"), ("guide", "Collection guide")):
            button = tk.Button(sidebar, text=title, command=lambda page=name: self._navigate(page), bg=NAVY, fg="#d6e1ed", activebackground=NAVY_LIGHT, activeforeground="white", relief="flat", bd=0, anchor="w", padx=18, pady=13, cursor="hand2", font=(FONT, 10))
            button.pack(fill="x", padx=12, pady=2)
            self.nav_buttons[name] = button
        bottom = tk.Frame(sidebar, bg=NAVY)
        bottom.pack(side="bottom", fill="x", padx=23, pady=25)
        tk.Frame(bottom, bg=NAVY_LIGHT, height=1).pack(fill="x", pady=(0, 16))
        tk.Label(bottom, text="EVIDENCE FIRST", bg=NAVY, fg="#e6edf5", font=(FONT, 9, "bold"), anchor="w").pack(fill="x")
        tk.Label(bottom, text="Inspect. Correlate. Recommend.\nNo automatic remediation.\nNo network uploads.", bg=NAVY, fg=NAVY_MUTED, font=(FONT, 9), justify="left", anchor="w", pady=8).pack(fill="x")
        tk.Label(bottom, text="Windows endpoint analysis", bg=NAVY, fg="#70869e", font=(FONT, 8), anchor="w").pack(fill="x", pady=(10, 0))

    def _header(self) -> None:
        header = tk.Frame(self.main, bg=BACKGROUND)
        header.grid(row=0, column=0, sticky="ew", padx=26, pady=(25, 18))
        header.grid_columnconfigure(0, weight=1)
        tk.Label(header, text="Windows endpoint analysis", bg=BACKGROUND, fg=INK, font=(FONT, 22, "bold"), anchor="w").grid(row=0, column=0, sticky="w")
        tk.Label(header, text="Find the failing stage. Review the evidence. Plan the next check.", bg=BACKGROUND, fg=MUTED, font=(FONT, 10), anchor="w").grid(row=1, column=0, sticky="w", pady=(6, 0))
        tk.Label(header, text="●  Read-only · Local processing", bg=TEAL_LIGHT, fg=TEAL, font=(FONT, 9, "bold"), padx=12, pady=8).grid(row=0, column=1, sticky="e", padx=(15, 0))
        actions = tk.Frame(header, bg=BACKGROUND)
        actions.grid(row=2, column=0, columnspan=2, sticky="ew", pady=(20, 0))
        self.import_button = ttk.Button(actions, text="+  Import logs", command=self._import_logs, style="Accent.TButton")
        self.import_button.pack(side="left", padx=(0, 8))
        self.sample_button = ttk.Button(actions, text="Load sample", command=self._load_sample)
        self.sample_button.pack(side="left", padx=(0, 8))
        self.collect_button = ttk.Button(actions, text="Collect this PC", command=self._collect)
        self.collect_button.pack(side="left", padx=(0, 8))
        self.export_button = ttk.Button(actions, text="Export report", command=self._export)
        self.export_button.pack(side="right")
        self.dataset_label = tk.Label(actions, text="No files imported", bg=BACKGROUND, fg=MUTED, font=(FONT, 9), anchor="w")
        self.dataset_label.pack(side="left", padx=9)
        if platform.system() != "Windows":
            self.collect_button.configure(state="disabled")

    def _filters(self) -> None:
        filters = tk.Frame(self.main, bg=BACKGROUND)
        filters.grid(row=1, column=0, sticky="ew", padx=26, pady=(0, 12))
        filters.grid_columnconfigure(0, weight=1)
        search_frame = tk.Frame(filters, bg=CARD, highlightthickness=1, highlightbackground=BORDER)
        search_frame.grid(row=0, column=0, sticky="ew", padx=(0, 10))
        tk.Label(search_frame, text="Search", bg=CARD, fg=MUTED, font=(FONT, 9), padx=10).pack(side="left")
        self.search_entry = tk.Entry(search_frame, textvariable=self.search, bg=CARD, fg=INK, insertbackground=INK, relief="flat", bd=0, font=(FONT, 10))
        self.search_entry.pack(side="left", fill="x", expand=True, pady=10, padx=(0, 10))
        ttk.Combobox(filters, textvariable=self.category, values=("All domains", *CATEGORIES), state="readonly", width=22).grid(row=0, column=1, padx=(0, 10))
        ttk.Combobox(filters, textvariable=self.severity, values=("All severities", "Error", "Warning", "Info", "Critical", "High", "Medium", "Low"), state="readonly", width=14).grid(row=0, column=2, padx=(0, 10))
        ttk.Button(filters, text="Clear", command=self._clear_filters).grid(row=0, column=3)

    def _card(self, parent: tk.Widget, **kwargs) -> tk.Frame:
        return tk.Frame(parent, bg=CARD, highlightthickness=1, highlightbackground=BORDER, **kwargs)

    def _section_title(self, parent: tk.Widget, title: str, subtitle: str | None = None) -> None:
        tk.Label(parent, text=title, bg=CARD, fg=INK, font=(FONT, 12, "bold"), anchor="w").pack(fill="x", padx=18, pady=(16, 3))
        if subtitle:
            tk.Label(parent, text=subtitle, bg=CARD, fg=MUTED, font=(FONT, 9), anchor="w", justify="left", wraplength=700).pack(fill="x", padx=18, pady=(0, 12))

    def _overview(self, frame: tk.Frame) -> None:
        frame.grid_columnconfigure(0, weight=3)
        frame.grid_columnconfigure(1, weight=2)
        frame.grid_rowconfigure(1, weight=2)
        frame.grid_rowconfigure(2, weight=1)
        metrics = tk.Frame(frame, bg=BACKGROUND)
        metrics.grid(row=0, column=0, columnspan=2, sticky="ew", pady=(0, 14))
        self.metric_values: dict[str, tk.Label] = {}
        for index, (key, title, hint, color) in enumerate((
            ("sources", "LOG SOURCES", "Files included in this analysis", INK),
            ("events", "EVIDENCE EVENTS", "Parsed records for correlation", INK),
            ("findings", "FINDINGS", "Evidence-backed diagnostic leads", TEAL),
            ("priority", "PRIORITY FINDINGS", "Errors requiring investigation", RED),
        )):
            metrics.grid_columnconfigure(index, weight=1, uniform="metric")
            card = self._card(metrics)
            card.grid(row=0, column=index, sticky="ew", padx=(0 if index == 0 else 5, 0 if index == 3 else 5))
            tk.Label(card, text=title, bg=CARD, fg=MUTED, font=(FONT, 8, "bold"), anchor="w").pack(fill="x", padx=16, pady=(15, 5))
            value = tk.Label(card, text="0", bg=CARD, fg=color, font=(FONT, 29, "bold"), anchor="w")
            value.pack(fill="x", padx=16)
            self.metric_values[key] = value
            tk.Label(card, text=hint, bg=CARD, fg=MUTED, font=(FONT, 8), anchor="w", wraplength=230).pack(fill="x", padx=16, pady=(3, 15))
        coverage = self._card(frame)
        coverage.grid(row=1, column=0, sticky="nsew", padx=(0, 7), pady=(0, 14))
        self._section_title(coverage, "Source coverage", "Coverage identifies the evidence you have, and what to collect next.")
        coverage_body = tk.Frame(coverage, bg=CARD)
        coverage_body.pack(fill="both", expand=True, padx=18, pady=(0, 12))
        self.coverage_rows: dict[str, tuple[tk.Label, tk.Label]] = {}
        for index, category in enumerate(CATEGORIES):
            row = tk.Frame(coverage_body, bg=CARD)
            row.pack(fill="x", pady=5)
            row.grid_columnconfigure(0, weight=1)
            tk.Label(row, text=category, bg=CARD, fg=INK, font=(FONT, 10, "bold"), anchor="w").grid(row=0, column=0, sticky="w")
            status = tk.Label(row, text="Missing evidence", bg="#f0f3f7", fg=MUTED, font=(FONT, 8), padx=8, pady=4)
            status.grid(row=0, column=1, sticky="e", padx=(8, 0))
            detail = tk.Label(row, text="", bg=CARD, fg=MUTED, font=(FONT, 8), anchor="w", justify="left", wraplength=480)
            detail.grid(row=1, column=0, columnspan=2, sticky="w", pady=(3, 2))
            self.coverage_rows[category] = status, detail
            if index < len(CATEGORIES) - 1:
                tk.Frame(coverage_body, bg="#edf1f6", height=1).pack(fill="x", pady=2)
        next_card = self._card(frame)
        next_card.grid(row=1, column=1, sticky="nsew", padx=(7, 0), pady=(0, 14))
        self._section_title(next_card, "Investigation focus", "Use the finding and its linked evidence to decide the next check.")
        self.focus_text = self._text(next_card, height=8)
        self.focus_text.pack(fill="both", expand=True, padx=17, pady=(0, 8))
        ttk.Button(next_card, text="Review findings  →", command=lambda: self._navigate("findings")).pack(anchor="w", padx=18, pady=(0, 16))
        correlation_card = self._card(frame)
        correlation_card.grid(row=2, column=0, sticky="nsew", padx=(0, 7))
        self._section_title(correlation_card, "Execution trace", "Assignment → Policy → Execution → Result · linked by shared IDs")
        self.trace_text = self._text(correlation_card, height=5)
        self.trace_text.pack(fill="both", expand=True, padx=17, pady=(0, 14))
        notes_card = self._card(frame)
        notes_card.grid(row=2, column=1, sticky="nsew", padx=(7, 0))
        self._section_title(notes_card, "Analysis notes", "Missing data and parser limitations matter to the conclusion.")
        self.notes_text = self._text(notes_card, height=5)
        self.notes_text.pack(fill="both", expand=True, padx=17, pady=(0, 14))

    def _tree(self, parent: tk.Widget, columns: tuple[str, ...], headings: tuple[str, ...], widths: tuple[int, ...], height: int = 12) -> ttk.Treeview:
        host = tk.Frame(parent, bg=CARD)
        host.pack(fill="both", expand=True)
        host.grid_rowconfigure(0, weight=1)
        host.grid_columnconfigure(0, weight=1)
        tree = ttk.Treeview(host, columns=columns, show="headings", selectmode="browse", height=height)
        for column, heading, width in zip(columns, headings, widths):
            tree.heading(column, text=heading, anchor="w")
            tree.column(column, width=width, minwidth=55, stretch=column in {"title", "message", "source"}, anchor="w")
        tree.grid(row=0, column=0, sticky="nsew")
        scroll_y = ttk.Scrollbar(host, orient="vertical", command=tree.yview)
        scroll_y.grid(row=0, column=1, sticky="ns")
        scroll_x = ttk.Scrollbar(host, orient="horizontal", command=tree.xview)
        scroll_x.grid(row=1, column=0, sticky="ew")
        tree.configure(yscrollcommand=scroll_y.set, xscrollcommand=scroll_x.set)
        tree.tag_configure("high", foreground=RED)
        tree.tag_configure("medium", foreground=AMBER)
        tree.tag_configure("stripe", background="#f7f9fc")
        return tree

    def _findings(self, frame: tk.Frame) -> None:
        frame.grid_rowconfigure(1, weight=1)
        frame.grid_columnconfigure(0, weight=1)
        top = tk.Frame(frame, bg=BACKGROUND)
        top.grid(row=0, column=0, sticky="ew", pady=(0, 12))
        tk.Label(top, text="Findings & suggested resolution", bg=BACKGROUND, fg=INK, font=(FONT, 15, "bold")).pack(side="left")
        self.finding_count = tk.Label(top, text="", bg=BACKGROUND, fg=MUTED, font=(FONT, 9))
        self.finding_count.pack(side="right")
        paned = ttk.Panedwindow(frame, orient="horizontal")
        paned.grid(row=1, column=0, sticky="nsew")
        list_card = self._card(paned)
        self._section_title(list_card, "Diagnostic leads", "Select a finding to inspect its evidence and suggested steps.")
        self.finding_tree = self._tree(list_card, ("severity", "title", "confidence"), ("Severity", "Finding", "Confidence"), (85, 280, 95))
        self.finding_tree.bind("<<TreeviewSelect>>", self._select_finding)
        self.findings_empty = tk.Label(list_card, text="", bg=CARD, fg=MUTED, font=(FONT, 9), anchor="w", justify="left", wraplength=440, padx=16, pady=10)
        self.findings_empty.pack(fill="x")
        detail_card = self._card(paned)
        self._section_title(detail_card, "Finding details", "Suggested steps are for review and are never executed by this application.")
        self.finding_detail = self._text(detail_card, height=24, scroll=True)
        self.finding_detail.master.pack(fill="both", expand=True, padx=17, pady=(0, 12))
        paned.add(list_card, weight=4)
        paned.add(detail_card, weight=5)

    def _timeline(self, frame: tk.Frame) -> None:
        frame.grid_rowconfigure(1, weight=1)
        frame.grid_columnconfigure(0, weight=1)
        title = tk.Frame(frame, bg=BACKGROUND)
        title.grid(row=0, column=0, sticky="ew", pady=(0, 12))
        tk.Label(title, text="Evidence timeline", bg=BACKGROUND, fg=INK, font=(FONT, 15, "bold")).pack(side="left")
        self.event_count = tk.Label(title, text="", bg=BACKGROUND, fg=MUTED, font=(FONT, 9))
        self.event_count.pack(side="right")
        paned = ttk.Panedwindow(frame, orient="vertical")
        paned.grid(row=1, column=0, sticky="nsew")
        timeline_card = self._card(paned)
        self._section_title(timeline_card, "Chronological evidence", "Timestamped events are ordered first. Records without timestamps follow in source order.")
        self.timeline_tree = self._tree(timeline_card, ("time", "source", "stage", "context", "codes", "message"), ("Timestamp", "Source", "Stage", "Context", "Error / event", "Evidence"), (180, 200, 110, 100, 135, 450), height=13)
        self.timeline_tree.bind("<<TreeviewSelect>>", self._select_event)
        self.timeline_empty = tk.Label(timeline_card, text="", bg=CARD, fg=MUTED, font=(FONT, 9), anchor="w", padx=16, pady=9)
        self.timeline_empty.pack(fill="x")
        event_card = self._card(paned)
        self._section_title(event_card, "Selected record", "Original line and correlation IDs connect this record to the diagnostic lead.")
        self.event_detail = self._text(event_card, height=7, scroll=True)
        self.event_detail.master.pack(fill="both", expand=True, padx=17, pady=(0, 12))
        paned.add(timeline_card, weight=3)
        paned.add(event_card, weight=1)

    def _guide(self, frame: tk.Frame) -> None:
        frame.grid_rowconfigure(1, weight=1)
        frame.grid_columnconfigure(0, weight=1)
        tk.Label(frame, text="Collection & investigation guide", bg=BACKGROUND, fg=INK, font=(FONT, 15, "bold"), anchor="w").grid(row=0, column=0, sticky="w", pady=(0, 12))
        scroll_host = tk.Frame(frame, bg=BACKGROUND)
        scroll_host.grid(row=1, column=0, sticky="nsew")
        canvas = tk.Canvas(scroll_host, bg=BACKGROUND, highlightthickness=0)
        scrollbar = ttk.Scrollbar(scroll_host, orient="vertical", command=canvas.yview)
        canvas.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side="right", fill="y")
        canvas.pack(side="left", fill="both", expand=True)
        body = tk.Frame(canvas, bg=BACKGROUND)
        window = canvas.create_window((0, 0), window=body, anchor="nw")
        body.bind("<Configure>", lambda event: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.bind("<Configure>", lambda event: canvas.itemconfigure(window, width=event.width))
        self.guide_canvas = canvas
        self.root.bind_all("<MouseWheel>", self._guide_scroll, add="+")
        intro = self._card(body)
        intro.pack(fill="x", pady=(0, 12))
        self._section_title(intro, "A safe evidence workflow", "This application processes imported files locally and suggests investigations. It never modifies policies, registry values, services, applications, or existing logs.")
        tk.Label(intro, text="1. Capture the incident time and affected workload.\n2. Collect relevant logs; export Entra sign-in evidence separately.\n3. Correlate timestamps, app or policy IDs, correlation IDs, and error codes.\n4. Review the failing stage and confirm the proposed cause.\n5. Test one approved remediation at a time outside this application.", bg=CARD, fg=INK, font=(FONT, 10), anchor="w", justify="left", padx=18, pady=4).pack(fill="x", pady=(0, 15))
        for guide in GUIDES:
            card = self._card(body)
            card.pack(fill="x", pady=(0, 12))
            self._section_title(card, guide["title"])
            for source in guide["sources"]:
                tk.Label(card, text=source, bg=CARD, fg=TEAL, font=(MONO_FONT, 9), anchor="w", justify="left", wraplength=920).pack(fill="x", padx=18, pady=3)
            tk.Label(card, text=guide["checks"], bg=CARD, fg=MUTED, font=(FONT, 10), anchor="w", justify="left", wraplength=900).pack(fill="x", padx=18, pady=(9, 16))
        codes_card = self._card(body)
        codes_card.pack(fill="x", pady=(0, 12))
        self._section_title(codes_card, "Conditional Access · error reference")
        for code, meaning in (("AADSTS53000", "Device is not compliant"), ("AADSTS53001", "Device is not joined to the required domain or join state"), ("AADSTS53003", "Access blocked by Conditional Access; inspect the failed policy")):
            row = tk.Frame(codes_card, bg=CARD)
            row.pack(fill="x", padx=18, pady=5)
            tk.Label(row, text=code, bg=TEAL_LIGHT, fg=TEAL, font=(MONO_FONT, 10, "bold"), padx=9, pady=5).pack(side="left")
            tk.Label(row, text=meaning, bg=CARD, fg=INK, font=(FONT, 10), anchor="w", wraplength=700).pack(side="left", padx=14)
        tk.Label(codes_card, text="An error code is a starting point. Confirm the device and policy details in the matching sign-in record.", bg=CARD, fg=MUTED, font=(FONT, 9), anchor="w", wraplength=920).pack(fill="x", padx=18, pady=(8, 16))
        cmd_card = self._card(body)
        cmd_card.pack(fill="x", pady=(0, 12))
        self._section_title(cmd_card, "Optional Autopilot diagnostic cabinet", "Run manually in an elevated Windows terminal when authorized. It writes a diagnostic cabinet; the application does not execute this command.")
        self.autopilot_command = r"mdmdiagnosticstool.exe -area Autopilot -cab C:\AutopilotDiag.cab"
        command_row = tk.Frame(cmd_card, bg=CARD)
        command_row.pack(fill="x", padx=18, pady=(0, 12))
        command = tk.Entry(command_row, relief="flat", bg="#f0f4f8", fg=INK, readonlybackground="#f0f4f8", font=(MONO_FONT, 10))
        command.insert(0, self.autopilot_command)
        command.configure(state="readonly")
        command.pack(side="left", fill="x", expand=True, ipady=10)
        ttk.Button(command_row, text="Copy command", command=self._copy_command).pack(side="right", padx=(10, 0))
        tk.Label(cmd_card, text="Extract the cabinet outside this application and import supported text, XML, JSON, or CSV files. CAB, ETL, and raw EVTX files may require export or conversion first. Collection on this PC exports readable evidence into a folder you choose.", bg=CARD, fg=MUTED, font=(FONT, 9), anchor="w", justify="left", wraplength=920).pack(fill="x", padx=18, pady=(0, 15))
        privacy_card = self._card(body)
        privacy_card.pack(fill="x", pady=(0, 12))
        self._section_title(privacy_card, "Sensitive data & reporting")
        tk.Label(privacy_card, text="Displayed evidence and exported reports use redacted text. Original diagnostic files remain unchanged and can still contain names, addresses, identifiers, paths, or secrets. Store collected files securely, review report content before sharing, and follow your organization's retention policy. Automated redaction may miss sensitive values.", bg=CARD, fg=MUTED, font=(FONT, 10), anchor="w", justify="left", wraplength=900).pack(fill="x", padx=18, pady=(3, 16))
        training = self._card(body)
        training.pack(fill="x", pady=(0, 8))
        self._section_title(training, "Enterprise troubleshooting practice")
        tk.Label(training, text="Intune & endpoint management  ·  Autopilot & MDM profiles  ·  Win32 packaging\nEntra ID & Conditional Access  ·  Defender & compliance  ·  Windows patch management\nPowerShell & reporting  ·  Enterprise migration  ·  L2 / L3 investigation", bg=CARD, fg=MUTED, font=(FONT, 10), anchor="w", justify="left", wraplength=920).pack(fill="x", padx=18, pady=(3, 16))

    def _footer(self) -> None:
        footer = tk.Frame(self.main, bg=BACKGROUND)
        footer.grid(row=4, column=0, sticky="ew", padx=26, pady=(0, 12))
        self.progress = ttk.Progressbar(footer, mode="indeterminate", style="Horizontal.TProgressbar")
        self.progress.pack(fill="x", pady=(0, 8))
        tk.Label(footer, textvariable=self.status, bg=BACKGROUND, fg=MUTED, font=(FONT, 9), anchor="w").pack(side="left", fill="x", expand=True)
        tk.Label(footer, text="Recommendations only · Verify before remediation", bg=BACKGROUND, fg=MUTED, font=(FONT, 8), anchor="e").pack(side="right")

    def _text(self, parent: tk.Widget, height: int, scroll: bool = False) -> tk.Text:
        host = tk.Frame(parent, bg=CARD) if scroll else parent
        text = tk.Text(host, bg=CARD, fg=INK, relief="flat", bd=0, wrap="word", font=(FONT, 10), height=height, padx=0, pady=3, cursor="arrow", selectbackground="#d9eeef", spacing1=3, spacing3=5)
        if scroll:
            text.pack(side="left", fill="both", expand=True)
            scrollbar = ttk.Scrollbar(host, orient="vertical", command=text.yview)
            scrollbar.pack(side="right", fill="y")
            text.configure(yscrollcommand=scrollbar.set)
        text.tag_configure("title", font=(FONT, 15, "bold"), foreground=INK, spacing3=12)
        text.tag_configure("heading", font=(FONT, 10, "bold"), foreground=TEAL, spacing1=11, spacing3=6)
        text.tag_configure("muted", foreground=MUTED, font=(FONT, 9))
        text.tag_configure("code", foreground=TEAL, font=(MONO_FONT, 9))
        text.tag_configure("warning", foreground=AMBER)
        text.tag_configure("severity", foreground=RED, font=(FONT, 10, "bold"))
        text.configure(state="disabled")
        return text

    def _set_text(self, widget: tk.Text, parts: list[tuple[str, str | None]]) -> None:
        widget.configure(state="normal")
        widget.delete("1.0", "end")
        for value, tag in parts:
            widget.insert("end", _safe(value), () if tag is None else (tag,))
        widget.configure(state="disabled")
        widget.yview_moveto(0)

    def _navigate(self, name: str) -> None:
        self.active_page = name
        self.pages[name].tkraise()
        for key, button in self.nav_buttons.items():
            button.configure(bg=TEAL if key == name else NAVY, fg="white" if key == name else "#d6e1ed", font=(FONT, 10, "bold" if key == name else "normal"))

    def _guide_scroll(self, event) -> None:
        if self.active_page == "guide" and event.delta:
            self.guide_canvas.yview_scroll(-int(event.delta / 120) or (-1 if event.delta > 0 else 1), "units")

    def _clear_filters(self) -> None:
        self.search.set("")
        self.category.set("All domains")
        self.severity.set("All severities")

    def _schedule_filter(self) -> None:
        if self.filter_after is not None:
            self.root.after_cancel(self.filter_after)
        self.filter_after = self.root.after(180, self._apply_search)

    def _apply_search(self) -> None:
        self.filter_after = None
        self._refresh_filtered()

    def _matches_finding(self, finding: Finding) -> bool:
        if self.category.get() != "All domains" and finding.category != self.category.get():
            return False
        if self.severity.get() != "All severities" and finding.severity.casefold() != self.severity.get().casefold():
            return False
        query = self.search.get().strip().casefold()
        if not query:
            return True
        events = {event.uid: event for event in self.result.events}
        linked = " ".join(" ".join((event.message, event.source, " ".join(event.codes), " ".join(event.correlation_ids))) for uid in finding.evidence if (event := events.get(uid)))
        content = " ".join((finding.title, finding.summary, finding.root_cause, finding.category, " ".join(finding.checks), " ".join(finding.recommendations), linked))
        return query in content.casefold()

    def _matches_event(self, event: Event, selected_uids: set[str] | None = None) -> bool:
        if self.category.get() != "All domains" and event.category != self.category.get():
            return False
        if selected_uids is not None and event.uid not in selected_uids:
            return False
        query = self.search.get().strip().casefold()
        return not query or query in " ".join((event.message, event.source, event.timestamp or "", event.stage, event.context, event.event_id or "", " ".join(event.codes), " ".join(event.correlation_ids))).casefold()

    def _refresh(self) -> None:
        self.metric_values["sources"].configure(text=str(len(self.result.sources)))
        self.metric_values["events"].configure(text=f"{len(self.result.events):,}")
        self.metric_values["findings"].configure(text=str(len(self.result.findings)))
        self.metric_values["priority"].configure(text=str(sum(f.severity.casefold() in {"error", "high", "critical"} for f in self.result.findings)))
        self.dataset_label.configure(text=f"{len(self.result.sources)} source{'s' if len(self.result.sources) != 1 else ''} · {'Synthetic sample' if self.demo else 'Local evidence'}" if self.result.sources else "No files imported")
        self.export_button.configure(state="normal" if self.result.sources and not self.busy else "disabled")
        if self.demo:
            self.banner_text.configure(text="SYNTHETIC SAMPLE  ·  These are demonstration records, not evidence from your device. Import local logs to start a real investigation.")
            self.banner.grid()
        elif not self.result.sources:
            self.banner_text.configure(text="START WITH EVIDENCE  ·  Import log files, try a synthetic sample, or use the collection guide to locate the right sources.")
            self.banner.grid()
        elif self.result.warnings:
            self.banner_text.configure(text=f"ANALYSIS NOTES  ·  {len(self.result.warnings)} note{'s' if len(self.result.warnings) != 1 else ''} affect coverage. Review the analysis notes below.")
            self.banner.grid()
        else:
            self.banner.grid_remove()
        self._refresh_coverage()
        self._refresh_focus()
        self._refresh_trace()
        notes: list[tuple[str, str | None]] = []
        if self.result.warnings:
            for warning in self.result.warnings:
                notes.append((f"• {warning}\n", "warning"))
        elif self.result.sources:
            notes.append(("No parser warnings were reported. Absence of a detected finding does not prove the endpoint is healthy.\n", "muted"))
        else:
            notes.append(("No evidence has been imported. The application cannot infer a device's state until logs are available.\n", "muted"))
        notes.append(("\nRecommendations need validation against the device and tenant configuration. Raw collected files may still contain sensitive data.", "muted"))
        if self.result.sources:
            notes.append(("\n\nImported sources\n", "heading"))
            for source in self.result.sources:
                notes.append((Path(source).name + "\n", "code"))
        self._set_text(self.notes_text, notes)
        self._refresh_filtered()

    def _refresh_coverage(self) -> None:
        # Count parsed evidence, never a selected-but-unreadable input. Structured
        # exports may keep the provider/channel in the event message instead of
        # the filename (for example, a generic "events.json" export).
        names = " ".join(f"{event.source} {event.message}".casefold() for event in self.result.events)
        expected = {
            "Win32 apps": (("AppWorkload.log", ("appworkload",)), ("IntuneManagementExtension.log", ("intunemanagementextension",)), ("AppActionProcessor.log", ("appactionprocessor",))),
            "Windows patching": (("WindowsUpdateClient/Operational", ("windowsupdateclient",)), ("CBS.log", ("cbs",)), ("UpdateOrchestrator", ("updateorchestrator",))),
            "Conditional Access": (("Entra sign-in export", ("signin", "sign-in", "conditional", "entra")),),
            "Autopilot & ESP": (("ModernDeployment/Autopilot", ("autopilot", "moderndeployment")), ("DeviceManagement/Admin", ("devicemanagement", "device-management")), ("Provisioning/Admin", ("provisioning",))),
            "Enterprise": (("DeviceManagement/Admin", ("devicemanagement", "device-management")),),
        }
        for category, (status, detail) in self.coverage_rows.items():
            count = sum(event.category == category for event in self.result.events)
            missing = [label for label, tokens in expected[category] if not any(token in names for token in tokens)]
            evidence = bool(count or len(missing) < len(expected[category]))
            status.configure(text=("Partial · " if missing else "") + f"{count:,} events" if count else "Source evidence" if evidence else "Missing evidence", bg=AMBER_LIGHT if evidence and missing else TEAL_LIGHT if evidence else "#f0f3f7", fg=AMBER if evidence and missing else TEAL if evidence else MUTED)
            if category == "Conditional Access":
                hint = "Use the relevant Entra sign-in JSON or CSV export; tenant policy evaluation is not available in local logs."
            elif category == "Enterprise":
                hint = "DeviceManagement-Enterprise-Diagnostics-Provider/Admin helps connect policy delivery to execution."
            elif category == "Win32 apps":
                hint = "AppWorkload.log · IntuneManagementExtension.log · AppActionProcessor.log"
            elif category == "Windows patching":
                hint = "WindowsUpdateClient/Operational · CBS.log · UpdateOrchestrator"
            else:
                hint = "ModernDeployment/Autopilot · DeviceManagement/Admin · Provisioning/Admin"
            detail.configure(text="Missing: " + " · ".join(missing) if self.result.sources and missing else hint)

    def _refresh_focus(self) -> None:
        priority = {"critical": 0, "error": 1, "high": 1, "warning": 2, "medium": 2, "low": 3, "info": 4}
        ordered = sorted(self.result.findings, key=lambda finding: priority.get(finding.severity.casefold(), 5))
        parts: list[tuple[str, str | None]] = []
        if ordered:
            finding = ordered[0]
            parts.extend(((finding.title + "\n", "heading"), (f"{finding.category}  ·  {finding.severity.title()} severity  ·  {finding.confidence} confidence\n\n", "muted"), (finding.summary + "\n", None), ("Likely cause\n", "heading"), (finding.root_cause + "\n", None)))
            if finding.checks:
                parts.extend((("Next validation\n", "heading"), (finding.checks[0], None)))
        elif self.result.sources:
            parts.extend((("No diagnostic finding was identified.\n", "heading"), ("Review the source coverage and analysis notes. Missing logs or unsupported record formats can leave the cause unresolved. Use the evidence timeline to inspect parsed records.\n", None)))
        else:
            parts.extend((("Build an evidence-backed investigation.\n", "heading"), ("Import Windows or Intune log files, then inspect the failing stage and the events that support each lead.\n\n", None), ("A synthetic sample demonstrates app detection, servicing, enrollment, and sign-in analysis.", "muted")))
        self._set_text(self.focus_text, parts)

    def _refresh_trace(self) -> None:
        linked: dict[str, list[Event]] = defaultdict(list)
        for event in self.result.events:
            for identifier in event.correlation_ids:
                linked[identifier].append(event)
        groups = sorted(linked.items(), key=lambda item: (-len({event.stage for event in item[1]}), -len(item[1]), item[0]))
        parts: list[tuple[str, str | None]] = []
        for identifier, events in groups[:4]:
            stages = set(event.stage.casefold() for event in events)
            parts.append((identifier + "\n", "code"))
            parts.append((" → ".join(f"{stage.title()} {'✓' if stage in stages else '—'}" for stage in ("assignment", "policy", "execution", "result")) + "\n", "muted"))
        if not parts:
            parts.append(("No shared correlation IDs are available yet. Collect adjacent policy and execution records to connect the full lifecycle.", "muted"))
        else:
            parts.append(("\nA shared ID links records; it does not prove that one event caused another.", "muted"))
        self._set_text(self.trace_text, parts)

    def _refresh_filtered(self) -> None:
        if not hasattr(self, "finding_tree"):
            return
        selected_id = self.selected_finding.id if self.selected_finding else None
        self.finding_tree.delete(*self.finding_tree.get_children())
        self.finding_rows.clear()
        priority = {"critical": 0, "error": 1, "high": 1, "warning": 2, "medium": 2, "low": 3, "info": 4}
        findings = sorted((finding for finding in self.result.findings if self._matches_finding(finding)), key=lambda finding: (priority.get(finding.severity.casefold(), 5), finding.category, finding.title))
        for index, finding in enumerate(findings):
            iid = f"f{index}"
            self.finding_rows[iid] = finding
            tags = ("high",) if finding.severity.casefold() in {"error", "high", "critical"} else ("medium",) if finding.severity.casefold() in {"warning", "medium"} else ("stripe",) if index % 2 else ()
            self.finding_tree.insert("", "end", iid=iid, values=(_safe(finding.severity.title()), _safe(finding.title), _safe(finding.confidence)), tags=tags)
        self.finding_count.configure(text=f"{len(findings)} of {len(self.result.findings)} findings")
        self.findings_empty.configure(text="" if findings else "No findings match the filters. Clear the filters to see all results." if self.result.findings else "No findings identified. Review coverage and analysis notes; missing evidence can leave the cause unresolved." if self.result.sources else "Import log files or load a sample to see diagnostic findings.")
        selected_row = next((iid for iid, finding in self.finding_rows.items() if finding.id == selected_id), None)
        if selected_row is None and self.finding_rows:
            selected_row = next(iter(self.finding_rows))
        if selected_row:
            self.finding_tree.selection_set(selected_row)
            self._show_finding(self.finding_rows[selected_row])
        else:
            self.selected_finding = None
            self._set_text(self.finding_detail, [("No finding selected\n", "title"), ("Import evidence or adjust the filters to review a diagnostic lead. Suggested resolutions will appear with the supporting records and validation checks.", "muted")])
        self.timeline_tree.delete(*self.timeline_tree.get_children())
        self.event_rows.clear()
        selected_uids: set[str] | None = None
        if self.severity.get() != "All severities":
            selected_uids = {uid for finding in self.result.findings if finding.severity.casefold() == self.severity.get().casefold() for uid in finding.evidence}
        events = sorted((event for event in self.result.events if self._matches_event(event, selected_uids)), key=_timestamp_key)
        # Keep the native view responsive when a very large diagnostic set is imported.
        view_limit = 12000
        for index, event in enumerate(events[:view_limit]):
            iid = f"e{index}"
            self.event_rows[iid] = event
            code = ", ".join(event.codes) or (f"Event {event.event_id}" if event.event_id else "—")
            values = (event.timestamp or "Timestamp unavailable", Path(event.source).name, event.stage.title(), event.context, code, event.message[:220].replace("\n", " "))
            self.timeline_tree.insert("", "end", iid=iid, values=tuple(_safe(value) for value in values), tags=("stripe",) if index % 2 else ())
        self.event_count.configure(text=f"{min(len(events), view_limit):,} of {len(self.result.events):,} events" + (" · view limited to 12,000" if len(events) > view_limit else ""))
        self.timeline_empty.configure(text="" if events else "No events match the filters. Clear filters or import the relevant evidence." if self.result.events else "No events are available. Import readable log files to build the timeline.")
        self._set_text(self.event_detail, [("Select a record above to inspect its timestamp, source line, IDs, context, and redacted message.", "muted")])

    def _select_finding(self, _event=None) -> None:
        selection = self.finding_tree.selection()
        if selection and selection[0] in self.finding_rows:
            self._show_finding(self.finding_rows[selection[0]])

    def _show_finding(self, finding: Finding) -> None:
        self.selected_finding = finding
        parts: list[tuple[str, str | None]] = [
            (finding.title + "\n", "title"),
            (f"{finding.category}  ·  {finding.severity.title()} severity  ·  {finding.confidence} confidence\n", "muted"),
            ("What the evidence shows\n", "heading"),
            (finding.summary + "\n", None),
            ("Likely root cause\n", "heading"),
            (finding.root_cause + "\n", None),
            ("Supporting evidence\n", "heading"),
        ]
        events = {event.uid: event for event in self.result.events}
        linked = sorted((events[uid] for uid in finding.evidence if uid in events), key=_timestamp_key)
        evidence_limit = 100
        for event in linked[:evidence_limit]:
            parts.append((f"{event.timestamp or 'Timestamp unavailable'}  ·  {Path(event.source).name}:{event.line}\n", "code"))
            parts.append((f"{event.stage.title()} · {event.context}" + (f" · {', '.join(event.codes)}" if event.codes else "") + "\n", "muted"))
            parts.append((event.message + "\n", None))
            if event.correlation_ids:
                parts.append(("IDs: " + ", ".join(event.correlation_ids) + "\n", "code"))
        if len(linked) > evidence_limit:
            parts.append((f"Showing the first {evidence_limit} linked records in chronological order. {len(linked) - evidence_limit:,} additional linked records are available in the evidence timeline and the complete exported report.\n", "muted"))
        if not linked:
            parts.append(("No linked event records are available. Validate this lead before acting.\n", "warning"))
        if finding.checks:
            parts.append(("Validation checks\n", "heading"))
            for index, check in enumerate(finding.checks, 1):
                parts.append((f"{index}. {check}\n", None))
        if finding.recommendations:
            parts.append(("Suggested resolution · not executed\n", "heading"))
            for index, recommendation in enumerate(finding.recommendations, 1):
                parts.append((f"{index}. {recommendation}\n", None))
        if finding.references:
            parts.append(("References\n", "heading"))
            for reference in finding.references:
                parts.append((reference + "\n", "code"))
        parts.append(("\nConfirm the cause against the current device and tenant settings. Test one approved remediation at a time outside this application.", "muted"))
        self._set_text(self.finding_detail, parts)

    def _select_event(self, _event=None) -> None:
        selection = self.timeline_tree.selection()
        if not selection or selection[0] not in self.event_rows:
            return
        event = self.event_rows[selection[0]]
        parts: list[tuple[str, str | None]] = [
            (f"{event.timestamp or 'Timestamp unavailable'}\n", "heading"),
            (f"Source: {event.source}  ·  Line: {event.line}\n", "code"),
            (f"Domain: {event.category}  ·  Stage: {event.stage}  ·  Context: {event.context}\n", "muted"),
        ]
        if event.event_id:
            parts.append((f"Event ID: {event.event_id}\n", "code"))
        if event.codes:
            parts.append(("Codes: " + ", ".join(event.codes) + "\n", "code"))
        if event.correlation_ids:
            parts.append(("Correlation IDs: " + ", ".join(event.correlation_ids) + "\n", "code"))
        parts.append(("\n" + event.message, None))
        self._set_text(self.event_detail, parts)

    def _set_busy(self, busy: bool, description: str = "") -> None:
        self.busy = busy
        state = "disabled" if busy else "normal"
        for button in (self.import_button, self.sample_button):
            button.configure(state=state)
        self.collect_button.configure(state=state if platform.system() == "Windows" else "disabled")
        self.export_button.configure(state="normal" if not busy and self.result.sources else "disabled")
        if busy:
            self.status.set(description)
            self.progress.start(13)
        else:
            self.progress.stop()
            self.progress.configure(value=0)

    def _run_job(self, function, on_success, description: str) -> None:
        if self.busy:
            return
        self._set_busy(True, description)

        def work() -> None:
            try:
                result = function()
            except Exception as error:
                self.jobs.put((False, error, None))
            else:
                self.jobs.put((True, result, on_success))

        threading.Thread(target=work, name="windows_diagnostics-local-analysis", daemon=True).start()

    def _poll(self) -> None:
        if self.closed:
            return
        try:
            while True:
                success, result, callback = self.jobs.get_nowait()
                self._set_busy(False)
                if success:
                    try:
                        callback(result)
                    except Exception as error:
                        self._show_error(error)
                else:
                    self._show_error(result)
        except queue.Empty:
            pass
        self.root.after(100, self._poll)

    def _show_error(self, error: Exception) -> None:
        self.status.set("Operation did not complete · Review the details")
        messagebox.showerror("Windows Diagnostics", _safe(error), parent=self.root)

    def _import_logs(self) -> None:
        if self.busy:
            return
        paths = filedialog.askopenfilenames(parent=self.root, title="Import local diagnostic evidence", filetypes=(("Readable diagnostic files", "*.log *.txt *.json *.jsonl *.ndjson *.csv *.xml"), ("Log / text files", "*.log *.txt"), ("JSON / CSV", "*.json *.jsonl *.ndjson *.csv"), ("XML event export", "*.xml"), ("Windows event log", "*.evtx"), ("All files", "*.*")))
        if paths:
            self._analyze(list(paths), demo=False)

    def _load_sample(self) -> None:
        if self.busy:
            return
        try:
            paths = _sample_files()
        except Exception as error:
            self._show_error(error)
            return
        self._analyze(paths, demo=True)

    def _analyze(self, paths: list[str], demo: bool) -> None:
        def work():
            from .engine import analyze_files
            return analyze_files(paths)

        def complete(result: AnalysisResult):
            result.synthetic = demo
            self.result = result
            self.demo = demo
            self.selected_finding = None
            self._clear_filters()
            self._refresh()
            self._navigate("overview")
            self.status.set(f"Analysis complete · {len(result.events):,} events · {len(result.findings)} findings" + (" · Synthetic sample" if demo else ""))

        self._run_job(work, complete, f"Analyzing {len(paths)} local file{'s' if len(paths) != 1 else ''} · Existing files remain unchanged")

    def _collect(self) -> None:
        if self.busy or platform.system() != "Windows":
            return
        directory = filedialog.askdirectory(parent=self.root, title="Choose a folder for raw diagnostic copies (may contain sensitive data)", mustexist=True)
        if not directory:
            return

        def work():
            from .collector import collect_windows
            from .engine import analyze_files
            collection = collect_windows(directory, max_events=500)
            analysis = analyze_files(collection.files)
            analysis.warnings = list(collection.warnings) + list(analysis.warnings)
            return analysis

        def complete(result: AnalysisResult):
            self.result = result
            self.demo = False
            self.selected_finding = None
            self._clear_filters()
            self._refresh()
            self._navigate("overview")
            self.status.set(f"Collection complete · {len(result.sources)} exported sources · {len(result.findings)} findings")

        self._run_job(work, complete, "Exporting raw diagnostic copies · Files may contain sensitive data · No settings changed")

    def _export(self) -> None:
        if self.busy or not self.result.sources:
            return
        filename = "windows-diagnostics-synthetic-sample" if self.demo else "windows-diagnostics-report"
        destination = filedialog.asksaveasfilename(parent=self.root, title="Export redacted analysis report", initialfile=filename + ".html", defaultextension=".html", filetypes=(("HTML report", "*.html"), ("JSON report", "*.json")))
        if not destination:
            return
        suffix = Path(destination).suffix.casefold()
        if suffix not in {".html", ".htm", ".json"}:
            self._show_error(ValueError("Choose an HTML (.html) or JSON (.json) report filename."))
            return
        result = self.result

        def work():
            from .reports import write_report
            return write_report(result, destination, format="json" if suffix == ".json" else "html")

        def complete(path):
            self.status.set(f"Report exported · {_safe(Path(path).name)} · All findings included")
            messagebox.showinfo("Report exported", "The redacted report was saved locally.\n\n" + _safe(path) + "\n\nReview report content before sharing.", parent=self.root)

        self._run_job(work, complete, "Writing a local report · All findings and evidence are included")

    def _copy_command(self) -> None:
        self.root.clipboard_clear()
        self.root.clipboard_append(self.autopilot_command)
        self.status.set("Autopilot diagnostic command copied · Run manually only when authorized")

    def _close(self) -> None:
        self.closed = True
        self.root.destroy()


def launch() -> None:
    """Start the desktop application; use CLI analysis for headless machines."""
    root = tk.Tk()
    DiagnosticApp(root)
    root.mainloop()


if __name__ == "__main__":
    launch()
