"""Evidence-based diagnostics with no remediation, network access or mutation."""

from __future__ import annotations

import hashlib
import json
import re
from collections import defaultdict
from dataclasses import replace
from datetime import datetime
from pathlib import Path

from .models import AnalysisResult, CATEGORIES, Event, Finding
from .parsers import MAX_EVENTS, parse_text
from .privacy import pseudonym, redact

MAX_FILE_BYTES = 20 * 1024 * 1024
MAX_TOTAL_BYTES = 100 * 1024 * 1024
MAX_FILES = 100
SUPPORTED_SUFFIXES = {".log", ".txt", ".json", ".jsonl", ".ndjson", ".csv", ".xml"}
PRIVACY_WARNING = "Redaction is heuristic and best effort. Review the report for sensitive data before sharing; pseudonyms allow correlation and are not anonymous. Analysis remains local."

_WIN32_DOC = "https://learn.microsoft.com/en-us/intune/app-management/deployment/troubleshoot-win32"
_CA_DOC = "https://learn.microsoft.com/en-us/entra/identity/conditional-access/troubleshoot-conditional-access"
_WU_DOC = "https://learn.microsoft.com/en-us/windows/deployment/update/windows-update-troubleshooting"
_AP_DOC = "https://learn.microsoft.com/en-us/autopilot/troubleshooting-faq"


def _has(event: Event, pattern: str) -> bool:
    return bool(re.search(pattern, event.message, re.I | re.S))


def _code(event: Event, code: str) -> bool:
    return code.casefold() in {c.casefold() for c in event.codes} or bool(re.search(r"(?<![\w])" + re.escape(code) + r"(?![\w])", event.message, re.I))


def _time(event: Event):
    try:
        return datetime.fromisoformat(event.timestamp.replace("Z", "+00:00")) if event.timestamp else None
    except (TypeError, ValueError):
        return None


def _success_only(event: Event) -> bool:
    success = _has(event, r'\b(?:no errors?|no failures?|successful|successfully)\b|(?<!["\'])\bsucceeded\b|"succeeded"\s*:\s*true')
    failure = _has(event, r"\b(?:failed|failure|not successful)\b")
    nonzero_error = _has(event, r"\berror code\s*[=:]?\s*(?!0(?:x0+)?\b)(?:0x[0-9a-f]+|[1-9]\d*)\b")
    return success and not (failure or nonzero_error)


def _installer_result(event: Event, code: str) -> bool:
    if _has(event, r"\b(?:configured|configuration|mapping|mappings|return codes)\b") and not _has(event, r"\b(?:returned|exited|completed with|process exit|execution result)\b"):
        return False
    return _has(event, r"\b(?:lpExitCode|exit\s*(?:code)?|return(?:ed)?\s*(?:code)?|msi\s*(?:error|code)|installer\s*(?:error|code|returned)|installer exited with code)\s*(?:is\b|was\b|equals\b|[=:])?\s*" + re.escape(code) + r"\b")


def _context_mismatch(event: Event) -> bool:
    if _has(event, r"\bcontext mismatch\b|\b(?:user|system) context\b[^.;\n]{0,80}\b(?:unsupported|incorrect|wrong)\b"):
        return not _success_only(event)
    expected = re.search(r"\b(?:expected|requires?|configured for|must run (?:as|in))\b[^.;\n]{0,40}?\b(user|system)\b", event.message, re.I)
    if not expected:
        return False
    actual = re.search(r"\b(?:actual|but|instead|running|executed)\b[^.;\n]{0,40}?\b(user|system)\b", event.message[expected.end():], re.I)
    return actual is not None and expected.group(1).casefold() != actual.group(1).casefold() and not _success_only(event)


def _mfa_observation(event: Event) -> bool:
    if _code(event, "AADSTS50076") or _code(event, "AADSTS50079"):
        return True
    position = event.message.find("{")
    if position >= 0:
        try:
            record = json.loads(event.message[position:])
        except (ValueError, TypeError):
            return False  # Do not treat arbitrary policy-name text as an outcome.
        if not isinstance(record, dict):
            return False
        status = record.get("status") or record.get("Status")
        if isinstance(status, dict):
            code = status.get("errorCode")
            reason = str(status.get("failureReason") or status.get("additionalDetails") or "")
        else:
            code = next((v for k, v in record.items() if re.sub(r"[\s_-]", "", k).casefold() == "signinerrorcode"), None)
            reason = next((str(v) for k, v in record.items() if re.sub(r"[\s_-]", "", k).casefold() == "failurereason"), "")
        try:
            failed = int(str(code)) != 0
        except (TypeError, ValueError):
            failed = False
        return failed and bool(re.search(r"\b(?:mfa|multifactor|multi-factor)\b.{0,80}\b(?:failed|denied|interrupted|required)\b", reason, re.I))
    return _has(event, r"\b(?:mfa|multifactor|multi-factor)\b[^.;\n]{0,80}\b(?:failed|denied|interrupted|required)\b") and not _success_only(event)


def _finding(key, title, category, matched, root_cause, checks, recommendations, severity="warning", confidence="medium", reference=None, summary=None):
    ids = list(dict.fromkeys(e.uid for e in matched))
    return Finding(
        id="finding-" + hashlib.sha256(key.encode()).hexdigest()[:12],
        title=title, category=category, severity=severity, confidence=confidence,
        summary=summary or f"{len(ids)} imported event(s) support this observation. Review the linked evidence and verify the proposed checks before any remediation.",
        root_cause=root_cause, evidence=ids,
        checks=checks, recommendations=recommendations,
        references=[reference] if reference else [],
    )


def analyze_events(events: list[Event], sources: list[str] | None = None, warnings: list[str] | None = None) -> AnalysisResult:
    """Return supported observations and manual suggestions, never perform fixes."""
    cleaned = []
    for event in events[:MAX_EVENTS]:
        identifiers = [value if str(value).startswith("[id:") else pseudonym(str(value)) for value in event.correlation_ids]
        cleaned.append(replace(event, source=redact(event.source), message=redact(event.message), correlation_ids=list(dict.fromkeys(identifiers)), category=event.category if event.category in CATEGORIES else "Enterprise"))
    result = AnalysisResult(events=cleaned, sources=list(dict.fromkeys(redact(str(s)) for s in (sources if sources is not None else [e.source for e in cleaned]))), warnings=[redact(w) for w in (warnings or [])])
    result.warnings.append(PRIVACY_WARNING)
    if len(events) > MAX_EVENTS:
        result.warnings.append(f"Only the first {MAX_EVENTS:,} events were analyzed. Split exports to inspect the remainder.")

    def add(key, title, category, predicate, root, checks, suggestions, severity="warning", confidence="medium", reference=None, summary=None):
        matched = [e for e in cleaned if (category == "Enterprise" or e.category == category) and predicate(e)]
        if matched:
            result.findings.append(_finding(key, title, category, matched, root, checks, suggestions, severity, confidence, reference, summary))

    add("win32-detection", "Win32 app detection failed after installation", "Win32 apps", lambda e: _code(e, "0x87d1041c"),
        "Intune reported that the application was not detected after installation (0x87D1041C). The imported evidence does not establish which detection condition or installer behavior caused the mismatch.",
        ["Compare the configured file, registry, MSI or script detection rule with the installed state and version.", "Review detection script exit code and standard output; check 32-bit versus 64-bit paths and registry views.", "Compare install context, detection context and timestamp with the installer result."],
        ["After verifying the intended installed state, propose a single detection or packaging adjustment for an authorized administrator to review. No rule is changed by this app."], confidence="high", reference=_WIN32_DOC)
    add("win32-1603", "Installer returned fatal error 1603", "Win32 apps", lambda e: _installer_result(e, "1603"),
        "1603 is a generic Windows Installer failure. It does not establish a unique root cause; the preceding installer error and verbose MSI log are needed.",
        ["Find the first failure before the final 1603 result in the MSI log (often before Return value 3).", "Review the exact command, package prerequisites, permissions and SYSTEM/User context."],
        ["Have an authorized administrator collect a verbose installer log in a separate diagnostic folder and propose remediation only for the confirmed preceding error."], reference=_WIN32_DOC)
    add("win32-1618", "Installer contention reported (1618)", "Win32 apps", lambda e: _installer_result(e, "1618"),
        "Windows Installer reported another installation already in progress. The logs do not identify the competing installation unless its process or package is explicitly recorded.",
        ["Correlate the timestamp with other deployment, servicing and Windows Installer events.", "Review configured retry behavior and dependency installation ordering."],
        ["Suggest rescheduling or retrying deployment after the competing installation completes; do not terminate installer processes or change settings automatically."], confidence="high", reference=_WIN32_DOC)
    for code, title, cause in (
        ("3010", "Installation succeeded; restart required (3010)", "3010 indicates successful installation with a restart required. This return code is not an installation failure."),
        ("1641", "Installation succeeded; restart initiated (1641)", "1641 indicates successful installation and a restart initiated by the installer. This return code is not an installation failure."),
    ):
        add("win32-" + code, title, "Win32 apps", lambda e, c=code: _installer_result(e, c), cause,
            ["Check the app's configured return-code mapping and post-restart detection evidence.", "Compare restart timing with dependent app and ESP progression."],
            ["Plan any required restart through the organization's approved process; this application never initiates a restart."], severity="info", confidence="high", reference=_WIN32_DOC)
    add("win32-dependency", "Win32 dependency blocks app progression", "Win32 apps", lambda e: _has(e, r"\bdependenc(?:y|ies)\b.{0,100}\b(?:failed|failure|not installed|unresolved|missing|blocked|timeout|timed out)\b|\b(?:failed|blocked|unresolved)\b.{0,60}\bdependenc(?:y|ies)\b") and not _success_only(e),
        "An explicit dependency failure or missing dependency was recorded. The parent app's failure may be downstream; verify the dependency's own first error before attributing a cause.",
        ["Trace the dependency app ID to its assignment, detection rule, command, context and exit code.", "Review dependency ordering, architecture and supersedence relationships."],
        ["Propose one correction for the confirmed dependency issue, then validate the dependent app in a controlled test."], reference=_WIN32_DOC)
    add("win32-assignment", "App assignment or applicability excludes deployment", "Win32 apps", lambda e: _has(e, r"\b(?:no applicable assignment|no assignments? (?:found|received)|assignment.{0,50}(?:excluded|not applicable|missing)|(?:excluded|not targeted).{0,50}(?:assignment|app|group)|requirements? (?:not met|failed))\b") and not _success_only(e),
        "The imported log explicitly records absent, excluded or inapplicable assignment/requirements. Tenant targeting and filter configuration must be verified to establish why.",
        ["Review include/exclude groups, assignment filters, availability, user/device targeting and requirement evaluations.", "Compare assignment delivery time with the local app evaluation."],
        ["Prepare a targeting or requirements change for administrator review only after the evaluated device/user is confirmed."], reference=_WIN32_DOC)
    add("win32-context", "Explicit SYSTEM/User context mismatch", "Win32 apps", _context_mismatch,
        "The log explicitly reports a context mismatch. A mere mention of SYSTEM and a user elsewhere is not sufficient to infer this issue.",
        ["Compare the intended install behavior with the recorded process identity.", "Check whether commands, per-user files, mapped drives or HKCU references require a specific context."],
        ["Propose a package/context adjustment for authorized review and test the exact command in the intended context."], reference=_WIN32_DOC)

    for code, title, root, checks in (
        ("0x800f081f", "Servicing source files were not found", "Servicing reported CBS_E_SOURCE_MISSING (0x800F081F). The matching repair/update source or missing payload must be identified; this code alone does not prove policy or component-store corruption.", ["Review the first associated CBS error and package/feature name.", "Verify Windows build, language and edition against the configured servicing source and effective source policy."]),
        ("0x800f0831", "Servicing reported component-store corruption", "Servicing reported CBS_E_STORE_CORRUPTION (0x800F0831), commonly associated with a missing package manifest/dependency. Confirm the named package and preceding CBS entry before proposing repair.", ["Review preceding CBS package/manifest errors and the required package identity.", "Compare prerequisite updates and the installed servicing/package state."]),
    ):
        add("patch-" + code, title, "Windows patching", lambda e, c=code: _code(e, c), root, checks,
            ["Prepare an evidence-backed servicing recommendation for an authorized administrator. No DISM repair, source changes or cleanup is performed."], confidence="high", reference=_WU_DOC)
    for code, label in (("0x80072ee2", "request timed out"), ("0x80072ee7", "name resolution failed"), ("0x80072efd", "connection could not be established")):
        add("patch-network-" + code, "Update network failure: " + label, "Windows patching", lambda e, c=code: _code(e, c),
            f"The recorded network operation {label} ({code.upper().replace('0X', '0x')}). The code does not distinguish DNS, proxy, firewall, endpoint availability or client configuration without accompanying evidence.",
            ["Identify the failing update endpoint and operation in WindowsUpdateClient and UpdateOrchestrator events.", "Compare recorded DNS/proxy/connectivity evidence with effective update source and policy delivery."],
            ["Suggest a narrowly scoped endpoint, DNS or proxy review only after the failing request is identified; preserve current settings."], confidence="high", reference=_WU_DOC)
    add("patch-reboot", "Update is waiting for a restart", "Windows patching", lambda e: _has(e, r"\b(?:restart|reboot)\b.{0,50}\b(?:required|pending|overdue)\b|\b(?:pending|required)\b.{0,30}\b(?:restart|reboot)\b") and not _has(e, r"\b(?:no|not)\s+(?:restart|reboot)\b|\b(?:restart|reboot) (?:not required|complete|completed)\b"),
        "An update-related restart requirement is explicitly recorded. This may block completion, but it is not evidence of a download or installation failure.",
        ["Review active hours, effective restart deadline, update installation status and the last recorded boot.", "Compare ring settings and local effective policy with MDM policy delivery events."],
        ["Plan the restart with the device owner through the existing approved process; the app does not restart devices."], severity="info", confidence="high", reference=_WU_DOC)
    add("patch-policy", "Update policy delivery or deadline issue recorded", "Windows patching", lambda e: _has(e, r"\b(?:policy|update ring|deadline)\b.{0,100}\b(?:failed|failure|not received|not applied|conflict|expired|overdue|missed)\b") and not _success_only(e),
        "An explicit update policy, conflict or deadline issue appears in the imported evidence. A local event does not establish the complete assigned ring or tenant policy precedence.",
        ["Compare assignment, MDM delivery, effective policy and the update execution/result timestamps.", "Review deadline/grace period values and any conflicting management source."],
        ["Prepare one policy or scheduling recommendation only after the effective settings are verified; retain existing configuration."], reference=_WU_DOC)

    for code, title, root, checks in (
        ("AADSTS53000", "Conditional Access: device not compliant", "Entra reported DeviceNotCompliant (AADSTS53000). The sign-in's compliance requirement was not satisfied at evaluation time; the specific failed compliance setting must be verified in Intune.", ["Review the failed Conditional Access policy and grant control in the same sign-in record.", "Compare the reported device ID, compliance evaluation and last check-in with the sign-in time."]),
        ("AADSTS53001", "Conditional Access: required device join state absent", "Entra reported DeviceNotDomainJoined (AADSTS53001). The required join condition was not satisfied for this sign-in; this code alone does not prove that the device is entirely unregistered or not Entra joined.", ["Review the actual failed policy device/join requirement in the sign-in record.", "Compare device identity, trust type and read-only dsregcmd /status output; verify whether the policy requires a hybrid joined device."]),
        ("AADSTS53003", "Conditional Access blocked the sign-in", "Entra reported BlockedByConditionalAccess (AADSTS53003). One or more Conditional Access evaluations prevented access; the code alone does not identify which policy or grant control caused the block.", ["Review failed applied policies, grant controls, authentication details and the recorded failure reason for this sign-in.", "Check device state, compliance and MFA results only against the failed policy's actual requirements."]),
    ):
        add("ca-" + code.lower(), title, "Conditional Access", lambda e, c=code: _code(e, c), root, checks,
            ["Prepare a device, authentication or policy recommendation only after the failed control is identified. Do not disable Conditional Access or bypass MFA."], severity="error", confidence="high", reference=_CA_DOC)
    add("ca-mfa", "Sign-in requires further MFA or records an MFA failure", "Conditional Access", _mfa_observation,
        "The sign-in requires additional MFA/registration, or explicitly records an MFA failure. Required MFA is not proof that a user failed a challenge; inspect authentication steps and the failure reason.",
        ["Review authentication details, challenge outcome, registration requirements and the failed policy controls."],
        ["Suggest completing the recorded authentication or registration requirement through the organization's existing process."], reference=_CA_DOC)
    add("join-observation", "Collected device reports AzureAdJoined: NO", "Enterprise", lambda e: _has(e, r"\bAzureAdJoined\s*:\s*NO\b"),
        "The imported dsregcmd-style output reports AzureAdJoined: NO. This is an observed device state, not evidence that a Conditional Access policy blocked a particular sign-in.",
        ["Review DomainJoined, WorkplaceJoined, device identity and collection context together.", "Compare this observation with the required join state and timestamp of any relevant Entra sign-in."],
        ["Review the intended device enrollment/join design with an authorized administrator before considering a change."], severity="info", confidence="high", reference=_CA_DOC)

    add("autopilot-tpm", "TPM or device attestation failure recorded", "Autopilot & ESP", lambda e: _has(e, r"\b(?:tpm|attestation)\b.{0,100}\b(?:failed|failure|error|not ready|not available|timeout|timed out|unsupported)\b") and not _success_only(e),
        "A TPM readiness or attestation failure is explicitly recorded. The logs must distinguish hardware readiness, firmware, certificate/attestation endpoint connectivity and deployment-mode requirements.",
        ["Review the exact attestation error, TPM readiness and Autopilot deployment mode.", "Correlate attestation request timestamps with DNS, proxy and endpoint failures."],
        ["Prepare a targeted firmware, readiness or connectivity recommendation for authorized review. Never clear the TPM or reset the device from this app."], reference=_AP_DOC)
    add("autopilot-esp", "Enrollment Status Page timeout recorded", "Autopilot & ESP", lambda e: _has(e, r"\b(?:esp|enrollment status page)\b.{0,120}\b(?:timeout|timed out|time limit|exceeded)\b|\b(?:timeout|timed out)\b.{0,60}\b(?:esp|enrollment status page)\b") and not _success_only(e),
        "ESP exceeded a recorded wait/time limit. A timeout is a symptom; identify the blocking app, policy or enrollment phase before assigning a root cause.",
        ["Identify the ESP phase and blocking app IDs in Autopilot and MDM diagnostics.", "Correlate blocking app assignment, dependency, execution, detection and exit-code evidence.", "Compare the recorded elapsed time with the configured ESP timeout and restart events."],
        ["Propose one change addressing the confirmed blocker and validate in a controlled deployment; do not bypass or change ESP automatically."], reference=_AP_DOC)
    add("autopilot-enrollment", "MDM enrollment failure recorded", "Autopilot & ESP", lambda e: _has(e, r"\b(?:mdm )?enroll(?:ment|ing)\b.{0,100}\b(?:failed|failure|error|denied|blocked)\b") and not _success_only(e),
        "Enrollment explicitly failed in the imported event. Tenant scope, permissions, restrictions, licensing and endpoint connectivity remain hypotheses unless an error or message specifically establishes them.",
        ["Review the first enrollment error code, MDM provider event and matching Autopilot profile timestamp.", "Verify enrollment scope, restrictions and intended identity against the recorded failure."],
        ["Prepare a recommendation for the confirmed enrollment error while preserving registration and current settings."], reference=_AP_DOC)
    add("autopilot-profile", "Autopilot profile or registration issue recorded", "Autopilot & ESP", lambda e: _has(e, r"\b(?:profile|hardware hash|registration)\b[^.;\n]{0,100}\b(?:not assigned|not found|not received|missing|duplicate|failed|failure)\b") and not _success_only(e),
        "The imported evidence explicitly records a profile/registration problem. It does not establish the full tenant assignment state or prove that a hardware hash should be deleted/reuploaded.",
        ["Review profile assignment, registration identity, group membership and delivery timing.", "Compare the recorded hardware/registration identity with the intended tenant and deployment profile."],
        ["Have an authorized administrator verify registration and targeting before proposing any change; preserve existing registrations."], reference=_AP_DOC)
    add("autopilot-network", "Autopilot connectivity failure recorded", "Autopilot & ESP", lambda e: any(_code(e, c) for c in ("0x80072ee2", "0x80072ee7", "0x80072efd")) or (_has(e, r"\b(?:dns|proxy|connectivity|connection)\b.{0,90}\b(?:failed|failure|error|unreachable|timeout|timed out)\b") and not _success_only(e)),
        "An Autopilot-stage request recorded a connectivity error. The affected endpoint and DNS/proxy response must be established before selecting a remediation.",
        ["Identify the failing hostname/request and compare its timestamp with enrollment, profile and attestation events.", "Review captured DNS, proxy and transport evidence for the recorded endpoint."],
        ["Propose a narrowly scoped connectivity review for the confirmed endpoint; do not reset networking or alter the proxy."], reference=_AP_DOC)

    _correlate(result)
    if not cleaned:
        result.warnings.append("No supported events were imported. Select text logs or exported event/sign-in JSON, CSV or XML.")
    else:
        if not any(e.timestamp for e in cleaned):
            result.warnings.append("No parseable timestamps were imported; a chronological or cross-source timeline cannot be established.")
        elif any(not e.timestamp for e in cleaned):
            result.warnings.append("Some events lack parseable timestamps and cannot be placed reliably on the timeline.")
        if any(e.timestamp and _time(e) and _time(e).tzinfo is None for e in cleaned):
            result.warnings.append("Some timestamps have no timezone. Local times are preserved; verify device timezone before correlating with UTC exports.")
        if not any(e.correlation_ids for e in cleaned):
            result.warnings.append("No correlation, activity, device or app identifiers were found. Time proximity alone cannot establish causation.")
        categories = {e.category for e in cleaned}
        if "Win32 apps" in categories:
            stages = {e.stage for e in cleaned if e.category == "Win32 apps"}
            missing = [stage for stage in ("assignment", "policy", "execution", "result") if stage not in stages]
            if missing:
                result.warnings.append("Win32 trace is incomplete: missing observed " + ", ".join(missing) + " stage(s). Include assignment/policy exports and the app's command, detection rule, dependency and context details.")
        if "Conditional Access" in categories and not any(_has(e, r"appliedConditionalAccessPolicies|conditionalAccessPolicies|failed polic|grantControl|authenticationDetails") for e in cleaned if e.category == "Conditional Access"):
            result.warnings.append("Conditional Access policy and authentication details are missing. Export the relevant Entra sign-in with applied policy results; local Windows logs cannot establish tenant policy evaluation.")
        if "Windows patching" in categories:
            result.warnings.append("Update ring assignments/effective settings and complete CBS/WindowsUpdateClient/MDM evidence may be absent. Imported snippets do not establish full servicing history.")
        if "Autopilot & ESP" in categories:
            result.warnings.append("Confirm Autopilot profile assignment and ESP phase/app details in the tenant and a diagnostic export; local snippets may not include the initial blocker.")
        if not result.findings:
            result.warnings.append("No known failure pattern was matched. This is not a clean bill of health; inspect the timeline and add the relevant complete diagnostic exports.")
    result.warnings = list(dict.fromkeys(result.warnings))
    return result


def _correlate(result: AnalysisResult):
    groups = defaultdict(list)
    for event in result.events:
        for identifier in event.correlation_ids:
            groups[identifier].append(event)
    candidates = []
    seen = set()
    for identifier, events in groups.items():
        unique = list({e.uid: e for e in events}.values())
        signature = tuple(sorted(e.uid for e in unique))
        if len(unique) < 2 or signature in seen:
            continue
        seen.add(signature)
        candidates.append((identifier, unique))
    # Report the largest shared-ID group first; bound report noise on long exports.
    for identifier, related in sorted(candidates, key=lambda pair: len(pair[1]), reverse=True)[:10]:
        stages = ", ".join(s for s in ("assignment", "policy", "execution", "result") if any(e.stage == s for e in related)) or "unclassified stages"
        result.findings.append(_finding("shared-" + identifier + "-" + "-".join(sorted(e.uid for e in related)), "Related events share a diagnostic identifier", "Enterprise", related,
            f"These events share {identifier}; observed stages: {stages}. Shared device/app/tenant IDs indicate association, not a causal chain. Inspect the exact identifier type and event order before attributing cause.",
            ["Trace assignment → policy → execution → result using the shared identifier and verified timestamps.", "Find the first explicit failure and distinguish later downstream symptoms.", "Time proximity alone does not establish causation."],
            ["Propose one remediation for the earliest confirmed failure, then validate its outcome with a fresh diagnostic export."], severity="info", confidence="medium"))
    if not candidates:
        # Only compare timestamps with the same awareness; never infer timezone.
        timed = [(_time(e), e) for e in result.events if _time(e)]
        for index, (stamp, event) in enumerate(timed[:2_000]):
            for other_stamp, other in timed[index + 1:index + 101]:
                if event.source == other.source or (stamp.tzinfo is None) != (other_stamp.tzinfo is None):
                    continue
                if abs((stamp - other_stamp).total_seconds()) <= 120:
                    result.findings.append(_finding("time-neighbors", "Cross-source events occur near the same time", "Enterprise", [event, other],
                        "Two imported sources contain events within two minutes. This is a timeline lead only; no shared identifier or causal link is established.",
                        ["Confirm device identity and timezones, then obtain matching activity/app/request IDs.", "Do not infer root cause from time proximity alone."],
                        ["Collect the matching identifier evidence before considering a remediation."], severity="info", confidence="low"))
                    return


def analyze_files(paths: list[str | Path]) -> AnalysisResult:
    """Read only explicitly selected local files, with bounded memory use."""
    events, sources, warnings = [], [], []
    total = 0
    seen = set()
    if len(paths) > MAX_FILES:
        warnings.append(f"Only the first {MAX_FILES} selected files are considered. Import the remaining files separately.")
    for candidate in paths[:MAX_FILES]:
        path = Path(candidate)
        source = redact(str(path))
        sources.append(source)
        try:
            resolved = str(path.resolve())
            if resolved in seen:
                warnings.append(f"Duplicate selected file skipped: {source}")
                continue
            seen.add(resolved)
            suffix = path.suffix.casefold()
            if suffix == ".evtx":
                warnings.append(f"Native EVTX cannot be parsed directly: {source}. On Windows, read the selected file with Get-WinEvent -Path and export records (TimeCreated, Id, ProviderName, Message, ActivityId, LogName) to JSON/CSV/XML in a new folder; then import that export.")
                continue
            if suffix == ".cab":
                warnings.append(f"CAB archive is not analyzed directly: {source}. Extract it into a new diagnostic folder (for example: expand.exe -F:* diagnostic.cab new-folder), then import its text/JSON/XML logs. Preserve the original archive and settings.")
                continue
            if suffix not in SUPPORTED_SUFFIXES:
                warnings.append(f"Unsupported file type: {source}. Supported imports are LOG, TXT, JSON, JSONL, NDJSON, CSV and XML.")
                continue
            if not path.is_file():
                warnings.append(f"Selected path is not a readable file: {source}")
                continue
            size = path.stat().st_size
            if size > MAX_FILE_BYTES:
                warnings.append(f"File exceeds the {MAX_FILE_BYTES // 1024 // 1024} MiB limit: {source}. Split or narrow the export.")
                continue
            if total + size > MAX_TOTAL_BYTES:
                warnings.append(f"Session import limit of {MAX_TOTAL_BYTES // 1024 // 1024} MiB reached; skipped {source}.")
                continue
            # Bounded read also handles a file growing after stat().
            with path.open("rb") as stream:
                raw = stream.read(MAX_FILE_BYTES + 1)
            if len(raw) > MAX_FILE_BYTES:
                warnings.append(f"File grew beyond the import limit: {source}; skipped. Export a stable snapshot.")
                continue
            total += len(raw)
            if raw.startswith((b"\xff\xfe", b"\xfe\xff")):
                text = raw.decode("utf-16")
            else:
                try:
                    text = raw.decode("utf-8-sig")
                except UnicodeDecodeError:
                    if b"\x00" in raw:
                        warnings.append(f"Unsupported binary or BOM-less UTF-16 file: {source}. Export as UTF-8 or UTF-16 with a byte-order mark.")
                        continue
                    text = raw.decode("cp1252", errors="replace")
                    warnings.append(f"Decoded {source} as Windows-1252 after UTF-8 failed; verify text and export encoding.")
            if "\x00" in text:
                warnings.append(f"NUL-containing binary or unsupported text rejected: {source}. Export diagnostic text as UTF-8 or UTF-16 with a byte-order mark.")
                continue
            parsed = parse_text(str(path), text)
            remaining = MAX_EVENTS - len(events)
            events.extend(parsed[:remaining])
            if len(parsed) >= MAX_EVENTS or len(parsed) > remaining:
                warnings.append(f"Event limit reached while importing {source}; only {MAX_EVENTS:,} events are considered. Split the export.")
            if not parsed:
                warnings.append(f"No events found in {source}.")
            if len(events) >= MAX_EVENTS:
                break
        except (OSError, UnicodeError, ValueError, RecursionError) as exc:
            warnings.append(f"Could not import {source}: {redact(str(exc))}")
    return analyze_events(events, sources, warnings)
