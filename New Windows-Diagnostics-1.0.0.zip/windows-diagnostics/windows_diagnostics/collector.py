"""Bounded, read-only diagnostics collection on the local Windows device.

The collector starts the bundled script without a shell or an execution policy
override. Its only writes are new diagnostic artifacts in the selected output
folder; it never executes any of the analysis engine's recommendations.
"""

from __future__ import annotations

import json
import os
from pathlib import Path
import platform
import subprocess

from .models import CollectionResult
from .resources import resource_path


_MANIFEST_PREFIX = "WINDOWS_DIAGNOSTICS_MANIFEST="
_SUPPORTED_SUFFIXES = {".log", ".txt", ".json", ".jsonl", ".ndjson", ".csv", ".xml"}
_MAX_EVENTS = 1000
_TIMEOUT_SECONDS = 120
_MAX_MANIFEST_BYTES = 2 * 1024 * 1024


def _powershell_executable() -> Path:
    # Use the Windows installation, rather than searching the current directory
    # or PATH for an executable with this name.
    windows_root = Path(os.environ.get("SystemRoot", r"C:\Windows"))
    return windows_root / "System32" / "WindowsPowerShell" / "v1.0" / "powershell.exe"


def _inside(path: Path, directory: Path) -> bool:
    try:
        path.relative_to(directory)
        return True
    except ValueError:
        return False


def _read_manifest(path: Path, output_root: Path) -> CollectionResult:
    manifest_path = path.resolve()
    if (
        manifest_path.name != "manifest.json"
        or manifest_path.parent == output_root
        or not _inside(manifest_path, output_root)
    ):
        raise RuntimeError("Collection returned a manifest outside its new output subfolder.")
    try:
        if manifest_path.stat().st_size > _MAX_MANIFEST_BYTES:
            raise RuntimeError("Collection manifest exceeds the supported size limit.")
        manifest = json.loads(manifest_path.read_text(encoding="utf-8-sig"))
    except (OSError, ValueError) as exc:
        raise RuntimeError(f"Could not read the collection manifest: {exc}") from exc
    if not isinstance(manifest, dict):
        raise RuntimeError("Collection returned an invalid manifest.")
    files = manifest.get("files")
    warnings = manifest.get("warnings")
    if (
        not isinstance(files, list)
        or not all(isinstance(item, str) for item in files)
        or not isinstance(warnings, list)
        or not all(isinstance(item, str) for item in warnings)
    ):
        raise RuntimeError("Collection manifest must contain file and warning lists.")

    result = CollectionResult(warnings=list(warnings))
    seen: set[Path] = set()
    for item in files:
        candidate = Path(item)
        if not candidate.is_absolute():
            candidate = manifest_path.parent / candidate
        candidate = candidate.resolve()
        if not _inside(candidate, manifest_path.parent) or candidate == manifest_path:
            raise RuntimeError("Collection manifest references a file outside its artifact folder.")
        if candidate in seen:
            continue
        seen.add(candidate)
        if candidate.suffix.lower() not in _SUPPORTED_SUFFIXES:
            result.warnings.append(f"Collected file cannot be analyzed directly: {candidate.name}.")
        elif not candidate.is_file():
            result.warnings.append(f"Collected file is unavailable: {candidate.name}.")
        else:
            result.files.append(str(candidate))
    if not result.files:
        result.warnings.append("No supported diagnostics were collected; review source and permission warnings.")
    return result


def collect_windows(output_dir: str | Path, max_events: int = 500) -> CollectionResult:
    """Collect local evidence without changing Windows, Intune, or device settings.

    Each call creates a new subfolder. Administrative access is not requested:
    inaccessible and missing sources become manifest warnings. Entra sign-in
    logs must be exported manually from the portal and imported separately.
    """
    if platform.system() != "Windows":
        raise RuntimeError("Local diagnostics collection is available only on Windows. Import exported logs instead.")
    if isinstance(max_events, bool) or not isinstance(max_events, int) or not 1 <= max_events <= _MAX_EVENTS:
        raise ValueError(f"max_events must be an integer between 1 and {_MAX_EVENTS}.")
    if not str(output_dir).strip():
        raise ValueError("Choose an output directory for the new diagnostics folder.")

    script = Path(resource_path("scripts/Collect-Diagnostics.ps1")).resolve()
    if not script.is_file():
        raise RuntimeError("The bundled Windows collector script is missing. Reinstall or use the complete project.")
    output_root = Path(output_dir).expanduser().resolve()
    try:
        output_root.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        raise RuntimeError(f"Could not create the diagnostics output directory: {exc}") from exc

    command = [
        str(_powershell_executable()),
        "-NoLogo",
        "-NoProfile",
        "-NonInteractive",
        "-File",
        str(script),
        "-OutputDirectory",
        str(output_root),
        "-MaxEvents",
        str(max_events),
    ]
    try:
        completed = subprocess.run(
            command,
            shell=False,
            check=False,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=_TIMEOUT_SECONDS,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
    except subprocess.TimeoutExpired as exc:
        raise RuntimeError(
            "Diagnostics collection timed out after 120 seconds. Partial artifacts may remain in the chosen "
            "output folder; no settings were changed and no files were deleted."
        ) from exc
    except OSError as exc:
        raise RuntimeError(f"Could not start the bundled Windows PowerShell collector: {exc}") from exc

    manifest_lines = [line[len(_MANIFEST_PREFIX):].strip() for line in completed.stdout.splitlines()
                      if line.startswith(_MANIFEST_PREFIX)]
    if len(manifest_lines) != 1 or not manifest_lines[0]:
        detail = (completed.stderr or completed.stdout).strip()[-1800:]
        message = (
            "Windows PowerShell did not produce a diagnostics manifest. The device's execution policy "
            "was respected; the app does not override it. Partial artifacts may remain in the output folder."
        )
        if detail:
            message += f" PowerShell reported: {detail}"
        raise RuntimeError(message)
    result = _read_manifest(Path(manifest_lines[0]), output_root)
    if completed.returncode:
        result.warnings.append(
            f"PowerShell exited with code {completed.returncode}; the available partial collection was imported."
        )
    return result
