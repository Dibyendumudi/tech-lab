"""Windows Diagnostics, managed by Dibyendu. Local, read-only diagnostics."""

__version__ = "1.0.0"
