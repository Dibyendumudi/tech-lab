"""Bounded parsers for text exports; native EVTX/CAB files are not interpreted."""

from __future__ import annotations

import csv
import hashlib
import io
import json
import re
import xml.etree.ElementTree as ET
from datetime import datetime, timezone
from pathlib import Path

from .models import Event
from .privacy import pseudonym, redact, redact_data

MAX_TEXT_CHARS = 20 * 1024 * 1024
MAX_EVENTS = 50_000
MAX_MESSAGE_CHARS = 16_384
_GUID = re.compile(r"(?i)\b[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\b")
_LABELED_ID = re.compile(r"(?i)\b(?:correlation|activity|relatedactivity|request|session|device|app(?:lication)?|tenant|object)[ _-]?id[\"']?\s*[=:]\s*[\"'{]?([\w.-]{3,})")
_CODES = re.compile(r"(?i)\b(?:0x[0-9a-f]{8}|AADSTS\d{5,8})\b")
_EXIT = re.compile(r"(?i)\b(?:lpExitCode|exit\s*(?:code)?|return(?:ed)?\s*(?:code)?|installer\s*(?:error|code)|msi\s*(?:error|code))\s*(?:is\b|was\b|equals\b|[=:])?\s*(1603|1618|3010|1641)\b")
_DECIMAL_CODE = re.compile(r"(?i)\b(?:HRESULT|(?:error|result|return|exit)\s*code|lpExitCode)\s*(?:is\b|was\b|equals\b|[=:])?\s*(-?\d{6,10})\b")
_CMTRACE = re.compile(r"<!\[LOG\[(.*?)\]LOG\]!><([^>]*)>", re.S)
_ATTR = re.compile(r'([\w]+)="([^"]*)"')
_STAMP = re.compile(r"\b(\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}(?:[.,]\d+)?(?:Z|[+-]\d{2}:?\d{2})?)\b")
_CORRELATION_KEYS = {"correlationid", "activityid", "relatedactivityid", "requestid", "sessionid", "deviceid", "appid", "applicationid", "tenantid", "objectid"}


def _key(value) -> str:
    return re.sub(r"[\s_-]", "", str(value)).casefold()


def _lookup(record: dict, *keys):
    wanted = {_key(k) for k in keys}
    return next((v for k, v in record.items() if _key(k) in wanted and v is not None), None)


def _timestamp(value) -> str | None:
    if isinstance(value, dict):
        value = value.get("DateTime") or value.get("value")
    if not value:
        return None
    value = str(value).strip()
    dotnet = re.fullmatch(r"/Date\((\d+)(?:[+-]\d{4})?\)/", value)
    if dotnet:
        try:
            return datetime.fromtimestamp(int(dotnet.group(1)) / 1000, timezone.utc).isoformat()
        except (ValueError, OverflowError, OSError):
            return None
    value = re.sub(r"(\.\d{6})\d+", r"\1", value).replace(",", ".")
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
        return (parsed.astimezone(timezone.utc) if parsed.tzinfo is not None else parsed).isoformat()
    except ValueError:
        pass
    for fmt in ("%m-%d-%Y %H:%M:%S.%f", "%m-%d-%Y %H:%M:%S", "%m/%d/%Y %H:%M:%S", "%m/%d/%Y %I:%M:%S %p", "%Y-%m-%d %H:%M:%S", "%d/%m/%Y %H:%M:%S"):
        try:
            return datetime.strptime(value, fmt).isoformat()
        except ValueError:
            pass
    return None


def _cmtrace_timestamp(attrs: dict) -> str | None:
    clock = attrs.get("time", "")
    # CMTrace may append a Windows timezone bias in minutes. Preserve local
    # clock time without guessing a timezone from incomplete exports.
    clock = re.sub(r"[+-]\d{1,3}$", "", clock)
    return _timestamp(f"{attrs.get('date', '')} {clock}")


def _category(source: str, message: str) -> str:
    text = (source + " " + message).casefold()
    if re.search(r"\baadsts\d+\b", text):
        return "Conditional Access"
    filename = str(source).replace("\\", "/").rsplit("/", 1)[-1].casefold()
    if any(name in filename for name in ("appworkload", "intunemanagementextension", "appactionprocessor")):
        return "Win32 apps"
    if any(x in text for x in ("conditionalaccess", "conditional access", "sign-in error", "signin", "sign-in logs")) or re.search(r"\bentra\b", text):
        return "Conditional Access"
    if any(x in text for x in ("autopilot", "enrollment status page", "esp timeout", "moderndeployment", "provisioning-diagnostics", "tpm attestation")):
        return "Autopilot & ESP"
    if any(x in text for x in ("windowsupdate", "windows update", "updateorchestrator", "cbs.log", "servicing", "update ring", "0x800f081f", "0x800f0831")):
        return "Windows patching"
    if any(x in text for x in ("appworkload", "intunemanagementextension", "appactionprocessor", "win32", "msiexec", "msi ", "0x87d1041c", "detection rule")):
        return "Win32 apps"
    if any(x in text for x in ("enrollment failed", "enrollment failure", "esp app", "esp phase")):
        return "Autopilot & ESP"
    return "Enterprise"


def _stage(message: str) -> str:
    text = message.casefold()
    if re.search(r"\b(?:lpexitcode|exitcode|returncode|exit code|return code|result|succeeded|success|failed|failure|detected|detection)\b", text):
        return "result"
    if re.search(r"\b(?:install(?:ing|ation)?|execut(?:e|ing|ion)|command line|download(?:ing)?)\b", text):
        return "execution"
    if re.search(r"\b(?:assignment|assigned|targeting|targeted|excluded)\b", text):
        return "assignment"
    if re.search(r"\b(?:policy|profile|ring|deadline)\b", text):
        return "policy"
    return "unknown"


def _context(message: str) -> str:
    # Mere mention of a user is not evidence of installer context.
    system = bool(re.search(r"(?i)\bSYSTEM\s+context\b|\b(?:context|running as|run as|executing as)\s*[=:]?\s*(?:NT AUTHORITY\\)?SYSTEM\b", message))
    user = bool(re.search(r"(?i)\bUSER\s+context\b|\b(?:context|running as|run as|executing as)\s*[=:]?\s*USER\b", message))
    return "mixed" if system and user else "SYSTEM" if system else "User" if user else "unknown"


def _ids(value) -> list[str]:
    found = []
    if isinstance(value, dict):
        for key, item in value.items():
            if _key(key) in _CORRELATION_KEYS and item and isinstance(item, (str, int)):
                found.append(pseudonym(str(item)))
            if isinstance(item, (dict, list)):
                found.extend(_ids(item))
    elif isinstance(value, list):
        for item in value:
            found.extend(_ids(item))
    elif isinstance(value, str):
        found.extend(pseudonym(m.group(0)) for m in _GUID.finditer(value))
        found.extend(pseudonym(m.group(1)) for m in _LABELED_ID.finditer(value))
    return list(dict.fromkeys(found))


def _event(source: str, message: str, line: int, timestamp=None, event_id=None, identifiers=None, category=None) -> Event:
    codes = [m.group(0).upper() if m.group(0).lower().startswith("aadsts") else m.group(0).lower() for m in _CODES.finditer(message)]
    codes.extend(m.group(1) for m in _EXIT.finditer(message))
    for match in _DECIMAL_CODE.finditer(message):
        value = int(match.group(1))
        if -2**31 <= value < 0 or 65_535 < value <= 2**32 - 1:
            codes.append(f"0x{value & 0xffffffff:08x}")
    safe_message = redact(message)
    if len(safe_message) > MAX_MESSAGE_CHARS:
        safe_message = safe_message[:MAX_MESSAGE_CHARS] + " [message truncated]"
    safe_source = redact(str(source))
    uid = "event-" + hashlib.sha256(f"{source}\0{line}\0{message}".encode("utf-8", errors="replace")).hexdigest()[:16]
    return Event(uid=uid, source=safe_source, category=category or _category(source, message), message=safe_message, timestamp=_timestamp(timestamp), line=line, event_id=str(event_id) if event_id is not None else None, correlation_ids=list(dict.fromkeys((identifiers or []) + _ids(message))), codes=list(dict.fromkeys(codes)), stage=_stage(message), context=_context(message))


def _record(source: str, record: dict, index: int) -> Event:
    # Graph sign-in export, including status, CA policies and device details.
    status = _lookup(record, "status")
    code = _lookup(record, "sign-in error code", "errorCode")
    sign_in = isinstance(status, dict) or _lookup(record, "conditionalAccessStatus", "appliedConditionalAccessPolicies", "conditionalAccessPolicies", "userPrincipalName") is not None
    if isinstance(status, dict):
        code = _lookup(status, "errorCode")
    if sign_in or _lookup(record, "sign-in error code") is not None:
        sign_in = True
        safe = redact_data(record)
        message = json.dumps(safe, ensure_ascii=False, default=str)
        try:
            error = int(str(code))
        except (TypeError, ValueError):
            error = 0
        if error:
            message = f"Entra sign-in AADSTS{error}: " + message
        else:
            message = "Entra sign-in export: " + message
        return _event(source, message, index, _lookup(record, "createdDateTime", "TimeCreated", "Date (UTC)", "Date", "timestamp"), identifiers=_ids(record), category="Conditional Access")
    message = _lookup(record, "Message", "RenderedDescription", "description")
    metadata = {k: v for k, v in record.items() if _key(k) not in {"message", "rendereddescription", "description", "timecreated", "timestamp", "datetime"}}
    safe_metadata = json.dumps(redact_data(metadata), ensure_ascii=False, default=str)
    message = (str(message) + "\n" if message is not None else "") + safe_metadata
    return _event(source, message, index, _lookup(record, "TimeCreated", "timestamp", "DateTime"), _lookup(record, "Id", "EventId", "Event ID"), _ids(record))


def _json_records(value) -> list[dict]:
    if isinstance(value, list):
        if any(not isinstance(item, dict) for item in value):
            raise ValueError("JSON records must be objects; export event or sign-in records as an array.")
        return value
    if isinstance(value, dict):
        for key in ("value", "events", "Events", "records", "signIns"):
            if key in value and isinstance(value[key], list):
                return _json_records(value[key])
        return [value]
    raise ValueError("JSON export must contain an object or array of event records.")


def _xml_events(source: str, text: str) -> list[Event]:
    if re.search(r"<!DOCTYPE|<!ENTITY", text, re.I):
        raise ValueError("XML declarations with DTD/entities are unsupported; export plain Windows Event XML.")
    try:
        root = ET.fromstring(text)
    except ET.ParseError as exc:
        raise ValueError(f"Malformed Windows Event XML: {exc}") from exc
    local = lambda tag: tag.rsplit("}", 1)[-1]
    nodes = [root] if local(root.tag) == "Event" else [node for node in root.iter() if local(node.tag) == "Event"]
    if not nodes:
        raise ValueError("XML contains no Windows Event records.")
    events = []
    for index, node in enumerate(nodes[:MAX_EVENTS], 1):
        record = {}
        data = {}
        for child in node.iter():
            tag = local(child.tag)
            content = (child.text or "").strip()
            if tag == "TimeCreated":
                record["TimeCreated"] = child.attrib.get("SystemTime")
            elif tag == "Provider":
                record["ProviderName"] = child.attrib.get("Name")
            elif tag in {"EventID", "Channel", "Computer", "Message"}:
                record[{"EventID": "Id", "Channel": "LogName", "Computer": "MachineName"}.get(tag, tag)] = content
            elif tag == "Security":
                record["UserId"] = child.attrib.get("UserID")
            elif tag == "Correlation":
                record.update(child.attrib)
            elif tag == "Data":
                data[child.attrib.get("Name", f"field{len(data)+1}")] = content
        record["EventData"] = data
        events.append(_record(source, record, index))
    return events


def parse_text(source: str, text: str) -> list[Event]:
    """Parse a text export. Raise ValueError for malformed structured inputs."""
    if len(text) > MAX_TEXT_CHARS:
        raise ValueError(f"Text exceeds the {MAX_TEXT_CHARS // 1024 // 1024} MiB import limit; split the export.")
    text = text.lstrip("\ufeff")
    if not text.strip():
        return []
    suffix = Path(source).suffix.casefold()
    if suffix in {".evtx", ".cab"}:
        raise ValueError("Native EVTX/CAB input is unsupported. Export events to JSON/CSV/XML or extract text logs from the CAB into a new folder.")
    if suffix in {".json", ".jsonl", ".ndjson"} or (suffix not in {".log", ".txt", ".csv", ".xml"} and text.lstrip().startswith(("{", "["))):
        try:
            records = _json_records(json.loads(text)) if suffix not in {".jsonl", ".ndjson"} else [json.loads(line) for line in text.splitlines() if line.strip()]
            if any(not isinstance(item, dict) for item in records):
                raise ValueError("Every JSON line must be an event object.")
        except json.JSONDecodeError as exc:
            raise ValueError(f"Malformed JSON export near line {exc.lineno}: {exc.msg}") from exc
        return [_record(source, record, index) for index, record in enumerate(records[:MAX_EVENTS], 1)]
    if suffix == ".xml" or text.lstrip().startswith(("<Events", "<Event ", "<Event>", "<?xml")):
        return _xml_events(source, text)
    if suffix == ".csv":
        try:
            reader = csv.DictReader(io.StringIO(text))
            if not reader.fieldnames or len(reader.fieldnames) < 2:
                raise ValueError("CSV requires named event or sign-in columns; export as comma-separated CSV.")
            records = []
            for index, record in enumerate(reader, 1):
                if index > MAX_EVENTS:
                    break
                if None in record:
                    raise ValueError(f"CSV row {index + 1} has more values than headers.")
                records.append(_record(source, record, index + 1))
            return records
        except csv.Error as exc:
            raise ValueError(f"Malformed CSV export: {exc}") from exc
    matches = list(_CMTRACE.finditer(text))
    if matches:
        events, previous_start, line = [], 0, 1
        for match in matches[:MAX_EVENTS]:
            line += text.count("\n", previous_start, match.start())
            previous_start = match.start()
            attrs = dict(_ATTR.findall(match.group(2)))
            events.append(_event(source, match.group(1), line, _cmtrace_timestamp(attrs)))
        return events
    events = []
    for line, message in enumerate(text.splitlines(), 1):
        if not message.strip():
            continue
        stamp = _STAMP.search(message)
        events.append(_event(source, message, line, stamp.group(1) if stamp else None))
        if len(events) >= MAX_EVENTS:
            break
    return events
