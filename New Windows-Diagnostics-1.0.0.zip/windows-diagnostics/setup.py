"""Include collector and synthetic examples in wheels without duplicating sources."""
from pathlib import Path
from shutil import copy2
from setuptools import setup
from setuptools.command.build_py import build_py


class ResourceBuild(build_py):
    def run(self):
        super().run()
        root = Path(__file__).resolve().parent
        destination = Path(self.build_lib) / 'windows_diagnostics' / 'data'
        for source_dir in ('examples', 'scripts'):
            for source in (root / source_dir).iterdir():
                if not source.is_file():
                    continue
                if source_dir == 'scripts' and source.name != 'Collect-Diagnostics.ps1':
                    continue
                target = destination / source_dir / source.name
                target.parent.mkdir(parents=True, exist_ok=True)
                copy2(source, target)


setup(cmdclass={'build_py': ResourceBuild})
