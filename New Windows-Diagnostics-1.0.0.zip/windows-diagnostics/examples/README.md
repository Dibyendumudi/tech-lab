These are synthetic troubleshooting records, not device telemetry. They illustrate an Intune detection failure after a successful installation, a successful install requiring reboot, patch DNS/source errors, Conditional Access error codes, and Autopilot/ESP failures. Event numbers in these examples are illustrative. No real customer identities or credentials are present.

Use **Load sample** in the desktop app, or run:

```text
py -m windows_diagnostics analyze --sample --output sample-report.html
```
