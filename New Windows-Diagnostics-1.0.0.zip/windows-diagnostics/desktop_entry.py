"""PyInstaller desktop entry point."""
from windows_diagnostics.ui import launch

if __name__ == '__main__':
    launch()
