import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from windows_diagnostics.engine import analyze_events, analyze_files
from windows_diagnostics.parsers import parse_text


class EngineTests(unittest.TestCase):
    def findings(self, source, text):
        return analyze_events(parse_text(source, text)).findings

    def test_distinct_ca_errors_and_policy_not_guessed(self):
        findings = self.findings('EntraSignIns.log', 'AADSTS53000\nAADSTS53001\nAADSTS53003')
        self.assertEqual(len(findings), 3)
        join = next(f for f in findings if 'join state' in f.title)
        self.assertIn('not prove', join.root_cause)
        blocked = next(f for f in findings if 'blocked' in f.title)
        self.assertIn('does not identify', blocked.root_cause)

    def test_reboot_success_codes_are_informational(self):
        findings = self.findings('AppWorkload.log', 'Installer exit code: 3010\nInstaller exit code: 1641')
        self.assertEqual(len(findings), 2)
        self.assertTrue(all(f.severity == 'info' for f in findings))
        self.assertTrue(all('not an installation failure' in f.root_cause for f in findings))
        self.assertTrue(any('initiated' in f.title for f in findings))

    def test_ime_actual_exit_variants_and_signed_detection_hresult(self):
        events = parse_text('IntuneManagementExtension.log', 'Installer finished, lpExitCode is 1603\nExitCode is 3010\nDetection HRESULT: -2016345060')
        self.assertIn('1603', events[0].codes)
        self.assertIn('3010', events[1].codes)
        self.assertIn('0x87d1041c', events[2].codes)
        self.assertTrue(all(event.stage == 'result' for event in events))
        result = analyze_events(events)
        self.assertEqual(len(result.findings), 3)
        reboot = next(f for f in result.findings if '3010' in f.title)
        self.assertEqual(reboot.severity, 'info')
        self.assertEqual(self.findings('AppWorkload.log', 'Configured lpExitCode is 1603'), [])

    def test_win32_detection_installer_dependencies_and_explicit_context(self):
        text = '\n'.join(['Detection failed 0x87D1041C', 'Installer exit code: 1603', 'Installer exit code: 1618', 'Dependency app failed to install', 'Expected user context but actual SYSTEM context', 'No applicable assignment'])
        findings = self.findings('AppActionProcessor.log', text)
        self.assertEqual(len(findings), 6)
        self.assertTrue(any('generic Windows Installer failure' in f.root_cause for f in findings))
        self.assertTrue(all(f.evidence for f in findings))

    def test_plain_mentions_and_successes_do_not_raise_failure(self):
        text = 'User signed in. SYSTEM context deployment succeeded.\nDependency installation succeeded.\nUser event 1603 recorded; 3010 records evaluated.\nTPM attestation succeeded.\nESP phase completed before timeout.'
        findings = self.findings('AppWorkload.log', text)
        self.assertEqual(findings, [])

    def test_same_context_and_configured_exit_codes_do_not_imply_failures(self):
        self.assertEqual(self.findings('AppWorkload.log', 'Expected SYSTEM context; actual SYSTEM context.'), [])
        self.assertEqual(self.findings('AppWorkload.log', 'Expected SYSTEM context but actual SYSTEM context.'), [])
        self.assertEqual(self.findings('AppWorkload.log', 'Configured installer return codes: 1603 = Failed; 3010 = Soft reboot; 1641 = Hard reboot; 1618 = Retry.'), [])
        self.assertEqual(self.findings('Autopilot.log', 'TPM attestation succeeded, error code 0.'), [])
        self.assertEqual(self.findings('Autopilot.log', 'ESP profile assigned. Blocking app installation failed.'), [])

    def test_report_only_ca_failure_is_not_enforced_block(self):
        records = [{'createdDateTime': '2026-10-13T08:00:00Z', 'status': {'errorCode': 0, 'failureReason': None}, 'conditionalAccessStatus': 'success', 'appliedConditionalAccessPolicies': [{'displayName': 'MFA policy', 'result': 'reportOnlyFailure'}], 'authenticationDetails': [{'succeeded': True, 'authenticationStepResultDetail': 'MFA completed'}]}]
        findings = self.findings('signins.json', json.dumps(records))
        self.assertEqual(findings, [])
        for policy_result in ('success', 'reportOnlyFailure'):
            records[0]['appliedConditionalAccessPolicies'][0].update(displayName='MFA required', result=policy_result, enforcedGrantControls=['Mfa'])
            self.assertEqual(self.findings('signins.json', json.dumps(records)), [])

    def test_patch_codes_root_observations_and_no_repair_execution(self):
        findings = self.findings('CBS.log', 'Source missing 0x800f081f\nPackage manifest missing 0x800f0831')
        self.assertEqual(len(findings), 2)
        self.assertTrue(any('SOURCE_MISSING' in f.root_cause for f in findings))
        self.assertTrue(any('STORE_CORRUPTION' in f.root_cause for f in findings))

    def test_update_network_scoped_to_update_events(self):
        findings = self.findings('WindowsUpdateClient.log', 'Scan failed 0x80072ee2\nDownload failed 0x80072ee7\nConnection failed 0x80072efd')
        self.assertEqual(len(findings), 3)
        self.assertEqual(self.findings('AppWorkload.log', 'Download failed 0x80072ee2'), [])

    def test_autopilot_explicit_failures_and_generic_timeout_negative(self):
        findings = self.findings('Autopilot.log', 'TPM attestation failed\nMDM enrollment failed\nESP app timed out\nDeployment profile not assigned\nDNS connection failed')
        self.assertEqual(len(findings), 5)
        self.assertEqual(self.findings('AppWorkload.log', 'Operation returned 0x800705B4\nKeyset 0x80090016'), [])
        self.assertEqual(self.findings('Autopilot.log', 'TPM attestation succeeded'), [])

    def test_dsreg_join_state_is_observation_not_ca_block(self):
        finding = self.findings('dsregcmd-status.txt', 'AzureAdJoined : NO\nDomainJoined : YES')[0]
        self.assertEqual(finding.severity, 'info')
        self.assertIn('not evidence', finding.root_cause)

    def test_deduplication_and_evidence_integrity(self):
        events = parse_text('AppWorkload.log', 'Detection failed 0x87D1041C\nDetection failed 0x87D1041C')
        result = analyze_events(events)
        self.assertEqual(len(result.findings), 1)
        self.assertEqual(result.findings[0].evidence, [e.uid for e in events])

    def test_shared_identifier_correlates_without_claiming_cause(self):
        events = parse_text('AppWorkload.log', '2026-10-13T08:00:00Z assignment appId=opaque-app-1\n2026-10-13T08:00:30Z installation appId=opaque-app-1')
        result = analyze_events(events)
        related = next(f for f in result.findings if 'share' in f.title)
        self.assertIn('not a causal chain', related.root_cause)
        self.assertNotIn('opaque-app-1', str(result.to_dict()))

    def test_time_neighbors_only_informational_and_timezone_mismatch_skipped(self):
        events = parse_text('one.log', '2026-10-13T08:00:00Z first') + parse_text('two.log', '2026-10-13T08:01:00Z second')
        result = analyze_events(events)
        finding = next(f for f in result.findings if 'same time' in f.title)
        self.assertEqual(finding.confidence, 'low')
        self.assertIn('no shared identifier or causal link', finding.root_cause)
        events = parse_text('one.log', '2026-10-13T08:00:00 first') + parse_text('two.log', '2026-10-13T08:01:00Z second')
        self.assertFalse(analyze_events(events).findings)

    def test_import_read_only_binary_rejections_duplicates_and_encoding(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            utf16 = root / 'AppWorkload.log'
            utf16.write_bytes('Installer exit code: 3010'.encode('utf-16'))
            before = utf16.read_bytes()
            evtx = root / 'events.evtx'
            evtx.write_bytes(b'ElfFile')
            cab = root / 'data.cab'
            cab.write_bytes(b'MSCF')
            bad = root / 'bad.json'
            bad.write_text('{broken', encoding='utf-8')
            result = analyze_files([utf16, utf16, evtx, cab, bad, root / 'missing.txt'])
            self.assertEqual(utf16.read_bytes(), before)
            self.assertEqual(len(result.events), 1)
            self.assertTrue(any('Duplicate' in w for w in result.warnings))
            self.assertTrue(any('Get-WinEvent -Path' in w for w in result.warnings))
            self.assertTrue(any('Extract it' in w for w in result.warnings))
            self.assertTrue(any('Malformed JSON' in w for w in result.warnings))
            self.assertTrue(any('not a readable file' in w for w in result.warnings))

    def test_bounded_import_never_reads_oversized_file(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / 'big.log'
            path.write_text('too long', encoding='utf-8')
            with patch('windows_diagnostics.engine.MAX_FILE_BYTES', 2):
                result = analyze_files([path])
            self.assertFalse(result.events)
            self.assertTrue(any('exceeds' in w for w in result.warnings))
            self.assertEqual(path.read_text(encoding='utf-8'), 'too long')

    def test_renamed_binary_is_rejected_not_healthily_parsed(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / 'renamed.log'
            path.write_bytes(b'ElfFile\x00\x00binary')
            result = analyze_files([path])
            self.assertFalse(result.events)
            self.assertTrue(any('binary' in w for w in result.warnings))


if __name__ == '__main__':
    unittest.main()
