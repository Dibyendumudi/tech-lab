import unittest

from windows_diagnostics.privacy import redact, redact_data


class PrivacyTests(unittest.TestCase):
    def test_identifiers_addresses_secrets_and_actionable_codes(self):
        text = 'alice@example.test 192.0.2.17 2001:db8::1 correlationId=11111111-2222-3333-4444-555555555555 password="secret phrase" Bearer eyJabcdef.abcdefgh.signature 0x800f081f AADSTS53003'
        safe = redact(text)
        for value in ('alice@example.test', '192.0.2.17', '2001:db8::1', '11111111-2222-3333-4444-555555555555', 'secret phrase', 'eyJabcdef'):
            self.assertNotIn(value, safe)
        self.assertIn('0x800f081f', safe)
        self.assertIn('AADSTS53003', safe)

    def test_recursive_fields_and_stable_pseudonyms(self):
        original = {'deviceDetail': {'deviceId': 'opaque-device-1', 'isCompliant': False}, 'status': {'errorCode': 53000}, 'User principal name': 'alice@example.test', 'MachineName': 'LAPTOP01', 'ActivityId': 'opaque-request-1', 'clientSecret': 'SECRET'}
        safe = redact_data(original)
        self.assertNotIn('opaque-device-1', str(safe))
        self.assertNotIn('alice@example.test', str(safe))
        self.assertNotIn('LAPTOP01', str(safe))
        self.assertNotIn('SECRET', str(safe))
        self.assertFalse(safe['deviceDetail']['isCompliant'])
        self.assertEqual(safe['status']['errorCode'], 53000)
        self.assertEqual(safe, redact_data(safe))
        self.assertEqual(original['MachineName'], 'LAPTOP01')

    def test_user_paths_redaction_is_idempotent(self):
        raw = r'C:\Users\Alice\AppData\Local\app.log /home/alice/logs.txt'
        safe = redact(raw)
        self.assertNotIn('Alice', safe)
        self.assertNotIn('/home/alice', safe)
        self.assertIn('app.log', safe)
        self.assertEqual(safe, redact(safe))

    def test_preserves_windows_log_path_timestamp_and_invalid_ip(self):
        text = r'C:\Windows\Logs\CBS\CBS.log 2026-10-13T08:02:03Z 999.1.2.3 exit code 3010'
        self.assertEqual(redact(text), text)

    def test_matching_ids_link_across_different_labels(self):
        guid = '11111111-2222-3333-4444-555555555555'
        self.assertEqual(redact('correlationId=' + guid).split('=')[1], redact('ActivityId=' + guid).split('=')[1])

    def test_labeled_device_sid_and_certificate(self):
        safe = redact('failed on device LAPTOP-DEMO01 userId=S-1-5-21-111-222-333-444 Thumbprint: AABBCCDDEEFF0011223344556677889900112233')
        self.assertNotIn('LAPTOP-DEMO01', safe)
        self.assertNotIn('S-1-5-21', safe)
        self.assertNotIn('AABBCCDDEEFF', safe)


if __name__ == '__main__':
    unittest.main()
