import json
import unittest

from windows_diagnostics.parsers import parse_text


class ParserTests(unittest.TestCase):
    def test_cmtrace_multiline_timestamp_codes_context_and_id(self):
        text = '<![LOG[Install running as SYSTEM\ncorrelationId=11111111-2222-3333-4444-555555555555 returned exit code: 3010]LOG]!><time="08:42:00.1234567+60" date="10-13-2026" component="AppWorkload" context="" type="1" thread="5" file="">'
        events = parse_text('AppWorkload.log', text)
        self.assertEqual(len(events), 1)
        self.assertEqual(events[0].timestamp, '2026-10-13T08:42:00.123456')
        self.assertEqual(events[0].category, 'Win32 apps')
        self.assertEqual(events[0].context, 'SYSTEM')
        self.assertIn('3010', events[0].codes)
        self.assertTrue(events[0].correlation_ids[0].startswith('[id:'))
        self.assertNotIn('11111111-', events[0].message)

    def test_windows_json_records_carry_channel_and_activity(self):
        record = {'TimeCreated': '2026-10-13T10:00:00+02:00', 'Id': 20, 'ProviderName': 'Microsoft-Windows-WindowsUpdateClient', 'LogName': 'Operational', 'ActivityId': 'opaque-activity-1', 'MachineName': 'SECRET-PC', 'Message': 'Scan failed: 0x80072ee7'}
        event = parse_text('events.json', json.dumps([record]))[0]
        self.assertEqual(event.timestamp, '2026-10-13T08:00:00+00:00')
        self.assertEqual(event.event_id, '20')
        self.assertEqual(event.category, 'Windows patching')
        self.assertNotIn('SECRET-PC', event.message)
        self.assertTrue(event.correlation_ids)
        self.assertIn('0x80072ee7', event.codes)

    def test_graph_signin_nested_error_and_privacy(self):
        record = {'createdDateTime': '2026-10-13T08:00:00Z', 'status': {'errorCode': 53003, 'failureReason': 'Blocked by Conditional Access'}, 'userPrincipalName': 'alice@example.test', 'correlationId': 'corr-token-9', 'deviceDetail': {'deviceId': 'dev-77', 'isCompliant': False}, 'appliedConditionalAccessPolicies': [{'id': 'policy-77', 'displayName': 'Sensitive policy name', 'result': 'failure'}]}
        event = parse_text('signins.json', json.dumps({'value': [record]}))[0]
        self.assertEqual(event.category, 'Conditional Access')
        self.assertIn('AADSTS53003', event.codes)
        self.assertIn('isCompliant', event.message)
        for raw in ('alice@example.test', 'corr-token-9', 'dev-77', 'Sensitive policy name'):
            self.assertNotIn(raw, event.message)

    def test_entra_csv_quoted_reason_newline_and_header_date(self):
        text = 'Date (UTC),User principal name,Sign-in error code,Failure reason,Correlation ID\n2026-10-13T08:00:00Z,alice@example.test,53000,"Device not compliant,\nblocked",corr-xyz\n'
        event = parse_text('export.csv', text)[0]
        self.assertIn('AADSTS53000', event.codes)
        self.assertEqual(event.timestamp, '2026-10-13T08:00:00+00:00')
        self.assertNotIn('alice@example.test', event.message)
        self.assertNotIn('corr-xyz', event.message)

    def test_windows_namespaced_xml(self):
        text = '<Events><Event xmlns="http://schemas.microsoft.com/win/2004/08/events/event"><System><Provider Name="Microsoft-Windows-ModernDeployment-Diagnostics-Provider"/><EventID>100</EventID><TimeCreated SystemTime="2026-10-13T08:00:00Z"/><Channel>Autopilot</Channel><Computer>SECRET-PC</Computer><Correlation ActivityID="11111111-2222-3333-4444-555555555555"/></System><EventData><Data Name="Error">TPM attestation failed</Data></EventData><RenderingInfo><Message>TPM attestation failed</Message></RenderingInfo></Event></Events>'
        event = parse_text('events.xml', text)[0]
        self.assertEqual(event.event_id, '100')
        self.assertEqual(event.category, 'Autopilot & ESP')
        self.assertTrue(event.correlation_ids)
        self.assertNotIn('SECRET-PC', event.message)

    def test_structured_errors_do_not_become_arbitrary_log_lines(self):
        for source, text in [('events.json', '{broken'), ('events.xml', '<broken'), ('events.csv', 'unnamed-column'), ('evil.xml', '<!DOCTYPE Event [<!ENTITY x "xx">]><Event/>'), ('events.jsonl', '{"Message":"one"}\nBAD')]:
            with self.subTest(source=source), self.assertRaises(ValueError):
                parse_text(source, text)

    def test_ids_and_numeric_dates_are_not_exit_codes(self):
        event = parse_text('notes.txt', '2026-10-13T08:00:00Z User event ID 1603; 3010 rows processed')[0]
        self.assertEqual(event.codes, [])
        self.assertEqual(event.context, 'unknown')

    def test_native_app_source_and_word_boundary_category_detection(self):
        self.assertEqual(parse_text('AppWorkload.log', 'central deployment installer exit code 3010')[0].category, 'Win32 apps')
        self.assertEqual(parse_text('AppWorkload.log', 'ESP phase installer exit code 3010')[0].category, 'Win32 apps')
        self.assertEqual(parse_text('AppWorkload.log', 'Entra sign-in error AADSTS53003')[0].category, 'Conditional Access')
        self.assertEqual(parse_text('notes.log', 'central deployment notes')[0].category, 'Enterprise')

    def test_unique_deterministic_uids_and_plain_timeline(self):
        events = parse_text('CBS.log', '2026-10-13 08:00:00 Servicing failed 0x800f081f\n2026-10-13 08:00:00 Servicing failed 0x800f081f')
        self.assertNotEqual(events[0].uid, events[1].uid)
        self.assertEqual(events, parse_text('CBS.log', '2026-10-13 08:00:00 Servicing failed 0x800f081f\n2026-10-13 08:00:00 Servicing failed 0x800f081f'))

    def test_jsonl_and_dotnet_time(self):
        event = parse_text('events.ndjson', '{"TimeCreated":"/Date(0)/","Message":"one"}\n')[0]
        self.assertEqual(event.timestamp, '1970-01-01T00:00:00+00:00')


if __name__ == '__main__':
    unittest.main()
