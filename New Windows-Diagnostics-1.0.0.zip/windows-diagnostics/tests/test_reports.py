import json
import tempfile
import unittest
from pathlib import Path

from windows_diagnostics.models import AnalysisResult, Event, Finding
from windows_diagnostics.reports import write_report


class ReportsTests(unittest.TestCase):
    def make_result(self):
        return AnalysisResult(
            events=[Event('event-1', 'sample.log', 'Win32 apps', '<script>alert(1)</script> user alice@example.test secret=PRIVATE-SECRET-123', timestamp='2026-10-12T08:00:00Z')],
            findings=[Finding('finding-1', 'Test finding', 'Win32 apps', 'high', 'medium', 'Summary', 'Unconfirmed cause', evidence=['event-1'], checks=['Read logs'], recommendations=['Review installer'], references=['javascript:alert(1)', 'https://learn.microsoft.com/en-us/mem/intune/apps/apps-win32-troubleshoot'])],
            sources=['sample.log'])

    def test_html_escapes_untrusted_evidence_and_links(self):
        with tempfile.TemporaryDirectory() as folder:
            target = write_report(self.make_result(), Path(folder) / 'report.html')
            text = target.read_text(encoding='utf-8')
            self.assertNotIn('<script>', text)
            self.assertIn('&lt;script&gt;', text)
            self.assertNotIn('javascript:', text)
            self.assertIn('href="#event-0"', text)
            self.assertNotIn('alice@example.test', text)
            self.assertNotIn('PRIVATE-SECRET-123', text)
            self.assertIn('No fixes were executed', text)

    def test_json_has_metadata_and_valid_evidence_links(self):
        with tempfile.TemporaryDirectory() as folder:
            target = write_report(self.make_result(), Path(folder) / 'report.json', 'json')
            data = json.loads(target.read_text(encoding='utf-8'))
            self.assertTrue(data['report_metadata']['read_only'])
            self.assertFalse(data['report_metadata']['remediations_executed'])
            self.assertEqual(data['findings'][0]['evidence'][0], data['events'][0]['uid'])
            self.assertNotIn('alice@example.test', target.read_text(encoding='utf-8'))

    def test_existing_reports_are_preserved(self):
        with tempfile.TemporaryDirectory() as folder:
            target = Path(folder) / 'report.html'
            target.write_text('existing report', encoding='utf-8')
            with self.assertRaises(FileExistsError):
                write_report(self.make_result(), target)
            self.assertEqual(target.read_text(encoding='utf-8'), 'existing report')

    def test_invalid_format_does_not_create_a_file(self):
        with tempfile.TemporaryDirectory() as folder:
            target = Path(folder) / 'report.bin'
            with self.assertRaises(ValueError):
                write_report(self.make_result(), target, 'bin')
            self.assertFalse(target.exists())


if __name__ == '__main__':
    unittest.main()
