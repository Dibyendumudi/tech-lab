"""Boundary tests for launching the read-only Windows collector safely."""

import json
from pathlib import Path
import subprocess
import tempfile
import unittest
from unittest.mock import patch

from windows_diagnostics.collector import collect_windows


class WindowsCollectorTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.output = self.root / "diagnostics"
        self.script = self.root / "trusted collector.ps1"
        self.script.write_text("# fixture; never executed", encoding="utf-8")
        self.windows = patch("windows_diagnostics.collector.platform.system", return_value="Windows")
        self.resource = patch("windows_diagnostics.collector.resource_path", return_value=self.script)
        self.windows.start()
        self.resource.start()
        self.addCleanup(self.windows.stop)
        self.addCleanup(self.resource.stop)
        self.addCleanup(self.temp.cleanup)

    def completion(self, output=None, names=None, warnings=None, returncode=0):
        folder = (output or self.output) / "Windows-Diagnostics-unique"
        folder.mkdir(parents=True)
        names = ["CBS.log"] if names is None else names
        for name in names:
            path = folder / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text("sample evidence", encoding="utf-8")
        manifest = folder / "manifest.json"
        manifest.write_text(json.dumps({"files": names, "warnings": warnings or []}), encoding="utf-8")
        return subprocess.CompletedProcess([], returncode, stdout=f"WINDOWS_DIAGNOSTICS_MANIFEST={manifest}\n", stderr="")

    def test_non_windows_rejects_without_creating_folder_or_starting_process(self):
        with patch("windows_diagnostics.collector.platform.system", return_value="Linux"), \
             patch("windows_diagnostics.collector.subprocess.run") as run:
            with self.assertRaisesRegex(RuntimeError, "only on Windows"):
                collect_windows(self.output)
        run.assert_not_called()
        self.assertFalse(self.output.exists())

    def test_arguments_are_explicit_and_output_metacharacters_are_literal(self):
        destination = self.root / "logs & $(unexpected) space"
        completion = self.completion(output=destination, warnings=["Raw logs may contain sensitive data."])
        with patch("windows_diagnostics.collector.subprocess.run", return_value=completion) as run:
            result = collect_windows(destination, max_events=25)
        command = run.call_args.args[0]
        options = run.call_args.kwargs
        self.assertEqual(command[command.index("-OutputDirectory") + 1], str(destination.resolve()))
        self.assertEqual(command[command.index("-File") + 1], str(self.script.resolve()))
        self.assertEqual(command[command.index("-MaxEvents") + 1], "25")
        self.assertNotIn("-ExecutionPolicy", command)
        self.assertNotIn("-Command", command)
        self.assertFalse(options["shell"])
        self.assertEqual(options["timeout"], 120)
        self.assertEqual([Path(item).name for item in result.files], ["CBS.log"])
        self.assertIn("Raw logs may contain sensitive data.", result.warnings)

    def test_invalid_event_limits_do_not_launch_collector(self):
        with patch("windows_diagnostics.collector.subprocess.run") as run:
            for invalid in (0, 1001, -1, True, 1.5, "500"):
                with self.subTest(value=invalid), self.assertRaises(ValueError):
                    collect_windows(self.output, max_events=invalid)
        run.assert_not_called()
        self.assertFalse(self.output.exists())

    def test_missing_bundle_is_reported_before_creating_output(self):
        with patch("windows_diagnostics.collector.resource_path", return_value=self.root / "missing.ps1"), \
             patch("windows_diagnostics.collector.subprocess.run") as run:
            with self.assertRaisesRegex(RuntimeError, "script is missing"):
                collect_windows(self.output)
        run.assert_not_called()
        self.assertFalse(self.output.exists())

    def test_manifest_must_be_under_selected_new_output_subfolder(self):
        outside = self.root / "elsewhere"
        completion = self.completion(output=outside)
        with patch("windows_diagnostics.collector.subprocess.run", return_value=completion):
            with self.assertRaisesRegex(RuntimeError, "outside its new output subfolder"):
                collect_windows(self.output)

    def test_root_manifest_cannot_be_used_as_a_collection_subfolder(self):
        self.output.mkdir()
        manifest = self.output / "manifest.json"
        manifest.write_text('{"files": [], "warnings": []}', encoding="utf-8")
        completion = subprocess.CompletedProcess([], 0, stdout=f"WINDOWS_DIAGNOSTICS_MANIFEST={manifest}\n", stderr="")
        with patch("windows_diagnostics.collector.subprocess.run", return_value=completion):
            with self.assertRaisesRegex(RuntimeError, "outside its new output subfolder"):
                collect_windows(self.output)

    def test_manifest_cannot_import_arbitrary_existing_files(self):
        completion = self.completion(names=[])
        manifest = Path(completion.stdout.strip().split("=", 1)[1])
        existing = self.root / "existing-secret.log"
        existing.write_text("private", encoding="utf-8")
        manifest.write_text(json.dumps({"files": [str(existing)], "warnings": []}), encoding="utf-8")
        with patch("windows_diagnostics.collector.subprocess.run", return_value=completion):
            with self.assertRaisesRegex(RuntimeError, "outside its artifact folder"):
                collect_windows(self.output)
        self.assertEqual(existing.read_text(encoding="utf-8"), "private")

    def test_partial_collection_preserves_warnings_and_skips_unavailable_or_binary_files(self):
        completion = self.completion(names=["CBS.log", "trace.etl"], warnings=["Access denied to event channel."], returncode=1)
        manifest = Path(completion.stdout.strip().split("=", 1)[1])
        content = json.loads(manifest.read_text(encoding="utf-8"))
        content["files"].extend(["missing.log", "CBS.log"])
        manifest.write_text(json.dumps(content), encoding="utf-8")
        with patch("windows_diagnostics.collector.subprocess.run", return_value=completion):
            result = collect_windows(self.output)
        self.assertEqual(len(result.files), 1)
        self.assertIn("Access denied to event channel.", result.warnings)
        self.assertTrue(any("cannot be analyzed directly" in warning for warning in result.warnings))
        self.assertTrue(any("unavailable: missing.log" in warning for warning in result.warnings))
        self.assertTrue(any("exited with code 1" in warning for warning in result.warnings))
        self.assertTrue((manifest.parent / "trace.etl").exists())

    def test_timeout_reports_partial_folder_and_leaves_existing_output_intact(self):
        self.output.mkdir()
        existing = self.output / "already-here.txt"
        existing.write_text("keep", encoding="utf-8")
        with patch("windows_diagnostics.collector.subprocess.run", side_effect=subprocess.TimeoutExpired("powershell", 120)):
            with self.assertRaisesRegex(RuntimeError, "timed out"):
                collect_windows(self.output)
        self.assertEqual(existing.read_text(encoding="utf-8"), "keep")

    def test_policy_block_does_not_retry_with_an_override(self):
        completion = subprocess.CompletedProcess([], 1, stdout="", stderr="running scripts is disabled on this system")
        with patch("windows_diagnostics.collector.subprocess.run", return_value=completion) as run:
            with self.assertRaisesRegex(RuntimeError, "execution policy was respected"):
                collect_windows(self.output)
        self.assertEqual(run.call_count, 1)

    def test_bad_manifest_types_are_rejected(self):
        completion = self.completion(names=[])
        manifest = Path(completion.stdout.strip().split("=", 1)[1])
        manifest.write_text('{"files": "CBS.log", "warnings": []}', encoding="utf-8")
        with patch("windows_diagnostics.collector.subprocess.run", return_value=completion):
            with self.assertRaisesRegex(RuntimeError, "file and warning lists"):
                collect_windows(self.output)


if __name__ == "__main__":
    unittest.main()
