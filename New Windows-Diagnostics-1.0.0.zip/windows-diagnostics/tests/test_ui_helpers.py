"""Test filtering semantics without needing a graphical display."""
import unittest
from windows_diagnostics.models import AnalysisResult, Event, Finding
from windows_diagnostics.ui import DiagnosticApp, _timestamp_key, _sample_files


class Value:
    def __init__(self, value):
        self.value = value

    def get(self):
        return self.value


class UIHelpersTests(unittest.TestCase):
    def app(self):
        app = DiagnosticApp.__new__(DiagnosticApp)
        app.category = Value('All domains')
        app.severity = Value('All severities')
        app.search = Value('')
        app.result = AnalysisResult(events=[Event('e1', 'AppWorkload.log', 'Win32 apps', 'detection error 0x87D1041C')])
        return app

    def test_search_finding_includes_its_linked_evidence(self):
        app = self.app()
        finding = Finding('f1', 'Detection failed', 'Win32 apps', 'warning', 'high', 'summary', 'cause', evidence=['e1'])
        app.search.value = '0x87d1041c'
        self.assertTrue(app._matches_finding(finding))
        app.category.value = 'Conditional Access'
        self.assertFalse(app._matches_finding(finding))

    def test_engine_severity_terms_filter_correctly(self):
        app = self.app()
        finding = Finding('f1', 'Blocked', 'Conditional Access', 'error', 'high', 'summary', 'cause')
        app.severity.value = 'Error'
        self.assertTrue(app._matches_finding(finding))
        app.severity.value = 'Warning'
        self.assertFalse(app._matches_finding(finding))

    def test_timeline_filter_respects_linked_event_ids(self):
        app = self.app()
        event = app.result.events[0]
        self.assertTrue(app._matches_event(event, {'e1'}))
        self.assertFalse(app._matches_event(event, {'other'}))

    def test_timeline_sorts_aware_offsets_by_instant(self):
        earlier = Event('e1', 'a.log', 'Enterprise', 'a', timestamp='2026-10-12T10:00:00+02:00')
        later = Event('e2', 'a.log', 'Enterprise', 'b', timestamp='2026-10-12T09:00:00Z')
        unknown = Event('e3', 'a.log', 'Enterprise', 'c')
        self.assertLess(_timestamp_key(earlier), _timestamp_key(later))
        self.assertLess(_timestamp_key(later), _timestamp_key(unknown))

    def test_sample_files_are_present(self):
        self.assertGreater(len(_sample_files()), 5)


if __name__ == '__main__':
    unittest.main()
