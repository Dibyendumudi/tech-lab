import contextlib
import hashlib
import io
import json
import tempfile
import unittest
from pathlib import Path

from windows_diagnostics.__main__ import main
from windows_diagnostics.engine import analyze_files
from windows_diagnostics.resources import resource_path


class IntegrationTests(unittest.TestCase):
    def test_sample_workflows_and_evidence_are_consistent(self):
        files = sorted(p for p in resource_path('examples').iterdir() if p.suffix in {'.log', '.json'})
        before = {p: (hashlib.sha256(p.read_bytes()).hexdigest(), p.stat().st_mtime_ns) for p in files}
        result = analyze_files(files)
        categories = {finding.category for finding in result.findings}
        self.assertTrue({'Win32 apps', 'Windows patching', 'Conditional Access', 'Autopilot & ESP', 'Enterprise'} <= categories)
        self.assertGreater(len(result.events), 10)
        uids = {event.uid for event in result.events}
        for finding in result.findings:
            self.assertTrue(finding.evidence)
            self.assertTrue(set(finding.evidence) <= uids)
            self.assertTrue(finding.checks)
            self.assertTrue(finding.recommendations)
        reboot = [finding for finding in result.findings if '(3010)' in finding.title]
        self.assertEqual(len(reboot), 1)
        self.assertEqual(reboot[0].severity, 'info')
        after = {p: (hashlib.sha256(p.read_bytes()).hexdigest(), p.stat().st_mtime_ns) for p in files}
        self.assertEqual(before, after, 'Analysis must leave source bytes and modification times intact.')

    def test_sample_cli_reports_are_labeled_and_existing_report_is_preserved(self):
        with tempfile.TemporaryDirectory() as folder, contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
            target = Path(folder) / 'demo.json'
            self.assertEqual(main(['analyze', '--sample', '--output', str(target)]), 0)
            data = json.loads(target.read_text(encoding='utf-8'))
            self.assertTrue(data['synthetic'])
            self.assertTrue(data['report_metadata']['synthetic'])
            original = target.read_bytes()
            self.assertEqual(main(['analyze', '--sample', '--output', str(target)]), 2)
            self.assertEqual(target.read_bytes(), original)

    def test_unreadable_logs_are_not_a_healthy_success(self):
        with tempfile.TemporaryDirectory() as folder, contextlib.redirect_stdout(io.StringIO()):
            target = Path(folder) / 'no-data.json'
            self.assertEqual(main(['analyze', str(Path(folder) / 'missing.log'), '--output', str(target)]), 2)
            data = json.loads(target.read_text(encoding='utf-8'))
            self.assertEqual(data['events'], [])
            self.assertTrue(data['warnings'])


if __name__ == '__main__':
    unittest.main()
