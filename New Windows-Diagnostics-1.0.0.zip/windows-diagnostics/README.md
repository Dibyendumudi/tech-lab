# Windows Diagnostics

**Managed by Dibyendu**

A local Windows desktop project for investigating Intune Win32 deployment, Windows patching, Conditional Access, Autopilot and ESP. It imports logs, correlates identifiers and timestamps, explains recognized failure patterns, and suggests checks and resolutions with linked evidence and confidence.

**No repair, deletion, restart, policy sync, settings change, or remediation is performed.** The collector reads existing logs and creates a new diagnostics folder. Analysis and reporting stay on the device; there are no cloud calls, credentials or telemetry.

## Run on Windows

Install Python 3.10 or later using the standard Windows installer with Tcl/Tk enabled. Extract this project, then double-click **Launch.cmd**, or open a terminal in the extracted directory:

```powershell
py -3 -m windows_diagnostics
```

The normal application needs no third-party packages. Use **Load sample** to explore synthetic scenarios, **Import logs** to analyze your exports, or **Collect this PC** to read supported sources from the Windows computer running the app. Background workers keep collection and analysis off the UI thread.

The source archive is `Windows-Diagnostics-1.0.0.zip`. An installable Python wheel is also provided. On Windows, `py -m pip install .\windows_diagnostics-1.0.0-py3-none-any.whl` installs the application and its bundled collection/sample resources. Then run `py -m windows_diagnostics` from any folder. This installs the app in Python; it does not change endpoint-management settings.

Select a finding to see the likely cause, evidence, verification questions and proposed next steps. Filter findings and the evidence timeline by category, severity or text. Export a new offline HTML report or structured JSON report for your case notes. Nothing in a recommendation can be executed from the app.

## Supported sources

| Workflow | Log sources | Investigation |
| --- | --- | --- |
| Win32 apps | `C:\ProgramData\Microsoft\IntuneManagementExtension\Logs\AppWorkload.log`, `IntuneManagementExtension.log`, `AppActionProcessor.log` | Assignment, applicability, detection after installation, dependency failures, SYSTEM/User context, commands, exit codes and reboot outcomes |
| Windows patching | `Microsoft-Windows-WindowsUpdateClient/Operational`, `C:\Windows\Logs\CBS\CBS.log`, text logs under `C:\Windows\Logs\UpdateOrchestrator\`, MDM Admin events | Scan/download connectivity, servicing source errors, policy delivery, pending reboots and deadlines; update ring configuration requires tenant evidence |
| Conditional Access | Microsoft Entra admin center → Monitoring & health → Sign-in logs → the sign-in → Conditional Access; JSON or CSV export | Failed policies, recorded grant controls, MFA, device compliance and join signals; 53000, 53001 and 53003 remain separate diagnoses |
| Autopilot & ESP | `Microsoft-Windows-ModernDeployment-Diagnostics-Provider/Autopilot`, MDM Admin, `Microsoft-Windows-Provisioning-Diagnostics-Provider/Admin`, IME app logs | Profile/enrollment failures, TPM symptoms, ESP timeouts, and DNS/proxy connectivity; hardware hash and profile assignment need portal confirmation |
| Enterprise | All relevant exports, including read-only `dsregcmd /status` output | Correlation identifiers, ordered assignment → policy → execution → result, collection gaps and data protection |

MDM Admin means `Microsoft-Windows-DeviceManagement-Enterprise-Diagnostics-Provider/Admin`. Collectors cannot read tenant assignments, update rings or Entra sign-ins from local event logs. Export that evidence separately from Intune or Entra.

The analyzer accepts CMTrace `.log` files, plain `.txt` logs, exported event/Entra `.json`, `.jsonl` or `.ndjson`, `.csv`, and Windows event `.xml`. Native `.evtx`, `.etl` and `.cab` files are not decoded. Convert the records to JSON/XML or extract the CAB into a new folder using Windows tools, then import its supported text files. Do not rename binary files to text extensions.

For a read-only conversion of an already-exported EVTX, run this manually in PowerShell, using a **new** output filename:

```powershell
Get-WinEvent -Path '.\ExportedEvents.evtx' |
  Select-Object @{Name='TimeCreated';Expression={$_.TimeCreated.ToUniversalTime().ToString('o')}}, Id, ProviderName, LogName, Message |
  ConvertTo-Json -Depth 5 | Out-File '.\ExportedEvents-new.json' -Encoding utf8
```

Additional Autopilot diagnostics can be collected manually with the corrected command below. It creates a CAB; use a fresh destination and sufficient permissions. The application displays the command for reference and never runs it:

```powershell
mdmdiagnosticstool.exe -area Autopilot -cab C:\AutopilotDiag.cab
```

## Read-only collection

**Collect this PC** uses the included fixed PowerShell script. Each run creates a unique subfolder under a folder you select; it never overwrites a previous collection. It reads up to 5 MiB from the tail of each target text log, at most 12 UpdateOrchestrator text logs, and up to 500 recent records per event channel by default (maximum 1,000). It also captures `dsregcmd /status`. Missing channels, access denials, policy restrictions, truncation and command failures are visible in notices and `manifest.json`.

Standard-user collection can be partial; the app never requests elevation or changes PowerShell execution policy. If your enterprise blocks unsigned scripts, use your approved signed collection process and import its exports. On non-Windows systems, file analysis and reporting work; Windows collection is disabled.

**Collection files are raw and may contain sensitive data.** Analysis and exported reports redact common identifiers, addresses, credentials and user paths using deterministic pseudonyms so related records can still be traced. Redaction is heuristic and does not guarantee removal of every secret or identity. Review any report before sharing, and protect the raw collection folder using your existing enterprise controls.

## Offline command line

```powershell
# Analyze a directory (one level) or explicit files; write a new report.
py -m windows_diagnostics analyze '.\logs' --output '.\case-report.html'
py -m windows_diagnostics analyze '.\logs\AppWorkload.log' '.\logs\signins.json' --output '.\case-report.json'

# Synthetic data only — does not analyze the local device.
py -m windows_diagnostics analyze --sample --output '.\sample-report.html'

# Windows only. Creates a unique collection folder under this parent.
py -m windows_diagnostics collect --output '.\diagnostics-output' --max-events 500
```

Reports refuse to overwrite existing files. Analysis returns exit code 0 when records were parsed, including when findings exist; unreadable/empty inputs and command failures return 2. A failure-free report is not proof of a healthy device.

## Interpreting root causes

Rules identify known codes and explicit log messages. High confidence means the recorded symptom matches a documented meaning; it does not prove the underlying configuration mistake. Generic errors such as MSI 1603, Conditional Access 53003 or an ESP timeout need the linked verification steps before a root cause can be confirmed. Exit codes 3010 and 1641 represent successful installations with reboot behavior rather than ordinary installation failures; custom Intune return-code mappings still need inspection.

Records sharing an identifier are grouped for traceability. Proximity in time is not treated as proof of causation. Timestamps without a timezone remain unspecified/local; compare source timezone settings before drawing a cross-source conclusion. Missing assignment, detection, dependency or tenant policy evidence is stated as a limitation.

For a real case, collect evidence for the affected time and device, confirm the proposed cause, and test **one approved remediation at a time** through your change process. This project provides suggestions, never applies them.

## Build a Windows executable

On a Windows development machine with the target architecture and Python installed:

```powershell
py -m pip install -r requirements-build.txt
py -m PyInstaller --noconfirm --clean --onefile --windowed --name Windows-Diagnostics --add-data "examples;examples" --add-data "scripts;scripts" desktop_entry.py
```

The output is `dist\Windows-Diagnostics.exe`. PyInstaller must run on Windows to build a Windows executable. The executable is not code-signed; use your enterprise signing/review process if distributing it. `scripts\Build-Windows.ps1` contains the same build commands and does not change system settings.

## Development and validation

```text
python -m unittest discover -s tests -v
python -m windows_diagnostics analyze --sample --output sample-report.html
```

Core parsing, rule behavior, redaction, safe report rendering and collector boundaries are unit-tested without changing Windows settings. This source project was built in a Linux environment. Native Windows collection, the Windows GUI and a packaged Windows executable still require validation on a Windows test device.

Project layout: `windows_diagnostics/engine.py` contains explainable diagnosis rules; `parsers.py` normalizes imported records; `privacy.py` redacts values; `collector.py` invokes the fixed collector; `ui.py` provides the desktop interface; `reports.py` writes offline reports; `tests/` contains regression checks; `examples/` contains synthetic training records.

Training coverage includes Intune endpoint management, Autopilot/MDM/configuration profiles, Win32 packaging, Entra Conditional Access, compliance/endpoint security, Windows patch management, PowerShell/reporting, and enterprise L2/L3 investigations. The initial rules focus on the requested deployment, patching, access and provisioning workflows; they do not perform antivirus, Defender or migration audits.
