# Run on Windows from an extracted source project. No system settings are changed.
$ErrorActionPreference = 'Stop'
if ($env:OS -ne 'Windows_NT') { throw 'A Windows executable must be built on Windows.' }
Push-Location (Split-Path -Parent $PSScriptRoot)
try {
    & py -m pip install -r requirements-build.txt
    if ($LASTEXITCODE -ne 0) { throw 'Build dependency installation failed.' }
    & py -m PyInstaller --noconfirm --clean --onefile --windowed --name Windows-Diagnostics --add-data 'examples;examples' --add-data 'scripts;scripts' desktop_entry.py
    if ($LASTEXITCODE -ne 0) { throw 'Executable build failed.' }
} finally { Pop-Location }
