# Collect local evidence only. Never change policy, sync, repair, restart,
# uninstall, remove a file, or run a suggested remediation.
# Windows PowerShell 5.1 or later. No administrator prompt or policy override.
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [string]$OutputDirectory,

    [ValidateRange(1, 1000)]
    [int]$MaxEvents = 500
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
$script:Files = New-Object 'System.Collections.Generic.List[string]'
$script:Warnings = New-Object 'System.Collections.Generic.List[string]'
$script:Sources = New-Object 'System.Collections.Generic.List[object]'
$MaxFileBytes = 5MB
$MaxOrchestratorFiles = 12
$MaxDiscoveryFiles = 256
$MaxMessageChars = 16384
$MaxEventDataChars = 16384
$StartedAt = [DateTime]::UtcNow.ToString('o')

function Add-Notice([string]$Message) {
    $script:Warnings.Add($Message)
}

function Write-NewText([string]$Path, [string]$Text) {
    # CreateNew refuses to overwrite even if a destination unexpectedly exists.
    $stream = [System.IO.File]::Open($Path, [System.IO.FileMode]::CreateNew,
        [System.IO.FileAccess]::Write, [System.IO.FileShare]::None)
    try {
        $encoding = New-Object System.Text.UTF8Encoding($false)
        $bytes = $encoding.GetBytes($Text)
        $stream.Write($bytes, 0, $bytes.Length)
    }
    finally { $stream.Dispose() }
}

function Copy-LogTail([string]$Source, [string]$Name) {
    $destination = Join-Path $script:CollectionDirectory $Name
    $inputStream = $null
    $outputStream = $null
    $detail = [ordered]@{ source = $Source; destination = $destination; status = 'unavailable' }
    try {
        $inputStream = [System.IO.File]::Open($Source, [System.IO.FileMode]::Open,
            [System.IO.FileAccess]::Read,
            ([System.IO.FileShare]::ReadWrite -bor [System.IO.FileShare]::Delete))
        $sourceBytes = $inputStream.Length
        $detail['source_bytes'] = $sourceBytes
        $bytesToRead = [Math]::Min($sourceBytes, $MaxFileBytes)
        $detail['truncated'] = ($sourceBytes -gt $MaxFileBytes)
        if ($sourceBytes -gt $MaxFileBytes) {
            [void]$inputStream.Seek(-$MaxFileBytes, [System.IO.SeekOrigin]::End)
            Add-Notice "$Source exceeds 5 MiB; only its last 5 MiB were copied. The first line may be partial."
        }
        $outputStream = [System.IO.File]::Open($destination, [System.IO.FileMode]::CreateNew,
            [System.IO.FileAccess]::Write, [System.IO.FileShare]::None)
        $buffer = New-Object byte[] 65536
        $copiedBytes = 0L
        while ($bytesToRead -gt 0) {
            $read = $inputStream.Read($buffer, 0, [int][Math]::Min($bytesToRead, $buffer.Length))
            if ($read -eq 0) { break }
            $outputStream.Write($buffer, 0, $read)
            $copiedBytes += $read
            $bytesToRead -= $read
        }
        $detail['copied_bytes'] = $copiedBytes
        $detail['status'] = 'collected'
        if ($bytesToRead -gt 0) {
            Add-Notice "$Source changed while being read; the snapshot may be incomplete."
            $detail['status'] = 'partial'
        }
        $script:Files.Add($destination)
    }
    catch {
        $detail['error'] = $_.Exception.Message
        Add-Notice "Could not collect $Source : $($_.Exception.Message). Existing diagnostic sources were left unchanged."
    }
    finally {
        if ($null -ne $outputStream) { $outputStream.Dispose() }
        if ($null -ne $inputStream) { $inputStream.Dispose() }
        $script:Sources.Add($detail)
    }
}

function Export-EventChannel([string]$Channel, [string]$Name) {
    $destination = Join-Path $script:CollectionDirectory $Name
    $detail = [ordered]@{ source = $Channel; destination = $destination; status = 'unavailable'; max_events = $MaxEvents }
    try {
        $events = @(Get-WinEvent -FilterHashtable @{ LogName = $Channel } -MaxEvents $MaxEvents -ErrorAction Stop)
        $records = New-Object 'System.Collections.Generic.List[object]'
        $truncatedCount = 0
        $formatFailures = 0
        foreach ($event in $events) {
            $message = ''
            try { $message = [string]$event.Message }
            catch { $formatFailures++ }
            $truncated = $false
            if ($message.Length -gt $MaxMessageChars) {
                $message = $message.Substring(0, $MaxMessageChars)
                $truncated = $true
            }
            $eventData = [ordered]@{}
            $activityId = ''
            $relatedActivityId = ''
            try {
                [xml]$xml = $event.ToXml()
                $correlation = $xml.SelectSingleNode("/*[local-name()='Event']/*[local-name()='System']/*[local-name()='Correlation']")
                if ($null -ne $correlation) {
                    $activityId = $correlation.GetAttribute('ActivityID')
                    $relatedActivityId = $correlation.GetAttribute('RelatedActivityID')
                }
                $dataNodes = $xml.SelectNodes("/*[local-name()='Event']/*[local-name()='EventData']/*[local-name()='Data']")
                $remainingChars = $MaxEventDataChars
                $dataIndex = 0
                foreach ($node in $dataNodes) {
                    if ($remainingChars -le 0 -or $dataIndex -ge 32) { $truncated = $true; break }
                    $key = $node.GetAttribute('Name')
                    if ([string]::IsNullOrEmpty($key)) { $key = "Data$dataIndex" }
                    $key = $key.Substring(0, [Math]::Min($key.Length, 128))
                    # Some event schemas repeat names; retain each field.
                    if ($eventData.Contains($key)) { $key = "$key#$dataIndex" }
                    $value = [string]$node.InnerText
                    $allowedChars = [Math]::Min($remainingChars, 2048)
                    if ($value.Length -gt $allowedChars) {
                        $value = $value.Substring(0, $allowedChars)
                        $truncated = $true
                    }
                    $eventData[$key] = $value
                    $remainingChars -= $value.Length
                    $dataIndex++
                }
            }
            catch { $formatFailures++ }
            if ($truncated) { $truncatedCount++ }
            $timestamp = $null
            if ($null -ne $event.TimeCreated) { $timestamp = $event.TimeCreated.ToUniversalTime().ToString('o') }
            $userId = $null
            if ($null -ne $event.UserId) { $userId = [string]$event.UserId }
            $records.Add([ordered]@{
                TimeCreated = $timestamp
                Id = $event.Id
                ProviderName = $event.ProviderName
                LevelDisplayName = $event.LevelDisplayName
                Message = $message
                RecordId = $event.RecordId
                LogName = $Channel
                MachineName = $event.MachineName
                UserId = $userId
                ActivityId = $activityId
                RelatedActivityId = $relatedActivityId
                EventData = $eventData
                Truncated = $truncated
            })
        }
        Write-NewText $destination (ConvertTo-Json -InputObject @($records.ToArray()) -Depth 8)
        $script:Files.Add($destination)
        $detail['status'] = 'collected'
        $detail['event_count'] = $records.Count
        $detail['truncated_events'] = $truncatedCount
        if ($events.Count -eq $MaxEvents) {
            Add-Notice "$Channel collection is capped at its latest $MaxEvents events; older evidence may be needed."
        }
        if ($truncatedCount -gt 0) { Add-Notice "$Channel has $truncatedCount event records with capped message or event-data text." }
        if ($formatFailures -gt 0) { Add-Notice "$Channel had $formatFailures message/XML formatting errors; some event details are unavailable." }
    }
    catch {
        $detail['error'] = $_.Exception.Message
        Add-Notice "Could not collect $Channel : $($_.Exception.Message). The channel may be empty, missing, disabled, or inaccessible to this account."
    }
    finally { $script:Sources.Add($detail) }
}

try {
    $root = [System.IO.Path]::GetFullPath($OutputDirectory)
    if (-not [System.IO.Directory]::Exists($root)) {
        [void][System.IO.Directory]::CreateDirectory($root)
    }
    $folderName = 'Windows-Diagnostics-' + [DateTime]::UtcNow.ToString('yyyyMMdd-HHmmss') + '-' + [Guid]::NewGuid().ToString('N')
    $script:CollectionDirectory = Join-Path $root $folderName
    [void](New-Item -ItemType Directory -Path $script:CollectionDirectory -ErrorAction Stop)
    Add-Notice 'Collected artifacts are raw and may contain usernames, device IDs, tenant IDs, application names, URLs, and other sensitive data. Review and redact copies before sharing.'
    Add-Notice 'This local collection does not include Entra sign-in or Conditional Access policy results. Export those logs manually from the Microsoft Entra portal and import the export.'

    $imeRoot = Join-Path $env:ProgramData 'Microsoft\IntuneManagementExtension\Logs'
    foreach ($name in @('AppWorkload.log', 'IntuneManagementExtension.log', 'AppActionProcessor.log')) {
        Copy-LogTail (Join-Path $imeRoot $name) $name
    }
    Copy-LogTail (Join-Path $env:SystemRoot 'Logs\CBS\CBS.log') 'CBS.log'

    $orchestratorRoot = Join-Path $env:SystemRoot 'Logs\UpdateOrchestrator'
    try {
        # Bound discovery as well as file count. Supported text files are copied;
        # binary ETL needs separate Windows Performance Analyzer interpretation.
        $discovered = @(Get-ChildItem -LiteralPath $orchestratorRoot -File -Recurse -ErrorAction Stop | Select-Object -First ($MaxDiscoveryFiles + 1))
        if ($discovered.Count -gt $MaxDiscoveryFiles) {
            Add-Notice 'UpdateOrchestrator file discovery stopped after 256 files; the snapshot may omit older or nested evidence.'
            $discovered = @($discovered | Select-Object -First $MaxDiscoveryFiles)
        }
        $supported = @($discovered | Where-Object { $_.Extension.ToLowerInvariant() -in @('.log', '.txt', '.json', '.xml') } | Sort-Object LastWriteTimeUtc -Descending)
        $unsupported = @($discovered | Where-Object { $_.Extension.ToLowerInvariant() -notin @('.log', '.txt', '.json', '.xml') })
        if ($unsupported.Count -gt 0) {
            Add-Notice "Skipped $($unsupported.Count) binary or unsupported UpdateOrchestrator files (including ETL). Review ETL separately using appropriate Windows tracing tools."
        }
        if ($supported.Count -gt $MaxOrchestratorFiles) {
            Add-Notice 'UpdateOrchestrator collection is capped at 12 supported text files, ordered by last modification time within the discovered set.'
        }
        if ($supported.Count -eq 0) { Add-Notice 'No supported text logs were found in Windows\Logs\UpdateOrchestrator.' }
        $index = 0
        foreach ($file in @($supported | Select-Object -First $MaxOrchestratorFiles)) {
            $index++
            Copy-LogTail $file.FullName ('UpdateOrchestrator_{0:D2}_{1}' -f $index, $file.Name)
        }
    }
    catch {
        Add-Notice "Could not enumerate $orchestratorRoot : $($_.Exception.Message). This account may lack permission, or the directory may be absent."
        $script:Sources.Add([ordered]@{ source = $orchestratorRoot; status = 'unavailable'; error = $_.Exception.Message })
    }

    Export-EventChannel 'Microsoft-Windows-WindowsUpdateClient/Operational' 'WindowsUpdateClient-Operational.json'
    Export-EventChannel 'Microsoft-Windows-DeviceManagement-Enterprise-Diagnostics-Provider/Admin' 'DeviceManagement-Enterprise-Diagnostics-Provider-Admin.json'
    Export-EventChannel 'Microsoft-Windows-ModernDeployment-Diagnostics-Provider/Autopilot' 'ModernDeployment-Diagnostics-Provider-Autopilot.json'
    Export-EventChannel 'Microsoft-Windows-Provisioning-Diagnostics-Provider/Admin' 'Provisioning-Diagnostics-Provider-Admin.json'

    $joinDestination = Join-Path $script:CollectionDirectory 'dsregcmd-status.txt'
    try {
        $dsreg = Join-Path $env:SystemRoot 'System32\dsregcmd.exe'
        $joinText = (& $dsreg /status 2>&1 | Out-String)
        $joinExitCode = $LASTEXITCODE
        if ($joinText.Length -gt 100KB) {
            $joinText = $joinText.Substring(0, 100KB)
            Add-Notice 'dsregcmd /status output was capped at 100 KiB of text.'
        }
        Write-NewText $joinDestination $joinText
        $script:Files.Add($joinDestination)
        $script:Sources.Add([ordered]@{ source = 'dsregcmd /status'; destination = $joinDestination; status = 'collected'; exit_code = $joinExitCode })
        Add-Notice 'dsregcmd was run under the current account; User State and SSO State describe this account and cannot establish SYSTEM or another user context.'
        if ($joinExitCode -ne 0) { Add-Notice "dsregcmd /status exited with code $joinExitCode; review its partial output." }
    }
    catch {
        Add-Notice "Could not read dsregcmd /status : $($_.Exception.Message)."
        $script:Sources.Add([ordered]@{ source = 'dsregcmd /status'; status = 'unavailable'; error = $_.Exception.Message })
    }

    $osDestination = Join-Path $script:CollectionDirectory 'Windows-OperatingSystem.json'
    try {
        $osInfo = Get-CimInstance -ClassName Win32_OperatingSystem -OperationTimeoutSec 10 -ErrorAction Stop |
            Select-Object Caption, Version, BuildNumber, OSArchitecture, LastBootUpTime
        Write-NewText $osDestination (ConvertTo-Json -InputObject $osInfo -Depth 4)
        $script:Files.Add($osDestination)
        $script:Sources.Add([ordered]@{ source = 'Win32_OperatingSystem'; destination = $osDestination; status = 'collected' })
    }
    catch {
        Add-Notice "Could not read basic operating-system information : $($_.Exception.Message)."
        $script:Sources.Add([ordered]@{ source = 'Win32_OperatingSystem'; status = 'unavailable'; error = $_.Exception.Message })
    }

    $manifestPath = Join-Path $script:CollectionDirectory 'manifest.json'
    $manifest = [ordered]@{
        schema_version = 1
        started_at = $StartedAt
        finished_at = [DateTime]::UtcNow.ToString('o')
        collection_directory = $script:CollectionDirectory
        read_only = $true
        files = @($script:Files.ToArray())
        warnings = @($script:Warnings.ToArray())
        sources = @($script:Sources.ToArray())
        limits = [ordered]@{ max_events_per_channel = $MaxEvents; max_file_bytes = $MaxFileBytes; max_orchestrator_files = $MaxOrchestratorFiles; max_discovered_files = $MaxDiscoveryFiles; max_message_chars = $MaxMessageChars; max_event_data_chars = $MaxEventDataChars }
    }
    Write-NewText $manifestPath (ConvertTo-Json -InputObject $manifest -Depth 12)
    Write-Output ('WINDOWS_DIAGNOSTICS_MANIFEST=' + $manifestPath)
    exit 0
}
catch {
    Write-Error "Collection could not complete: $($_.Exception.Message). Any new partial artifacts remain in the selected output directory. No source files or device settings were modified." -ErrorAction Continue
    exit 1
}
